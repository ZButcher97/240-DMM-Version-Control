#include "WDGT.h"
//----------------------------------------------------------//
void WWDGT_init(void)
{
	RCC->APB1ENR|=RCC_APB1ENR_WWDGEN; //Clock enable of Windown Watchdog
	WWDG->CFR |= (3u<<8);
	WWDG->CFR |= (127<<6);
	WWDG->CR |= (255u<<7);							//WDGT enable bit in CR AND 1 in the T6 bit to avoid immediate reset
}
//----------------------------------------------------------//



//----------------------------------------------------------//
void WWDGT_Refresh(void)
{
	WWDG->CR |= (255u<<7);
}
//----------------------------------------------------------//



//----------------------------------------------------------//
void IWDGT_init(void)
{
	IWDG->KR = IWDGT_UnlockKey;																//unlock PR and RLR registers with unlock key
	IWDG->PR = 0x7;																						//Set prescaler registrer
	IWDG->RLR = 0xFFF;																				//set reload register
	IWDG->KR = IWDGT_StartVal;																//start watchdog
}
//----------------------------------------------------------//



//----------------------------------------------------------//
void IWDGT_Refresh(void)
{
	IWDG->KR = IWDGT_ResetVal;																//refresh the watchdog
}
//----------------------------------------------------------//

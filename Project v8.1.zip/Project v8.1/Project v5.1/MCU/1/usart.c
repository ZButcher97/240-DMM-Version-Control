#include "usart.h"
#include <stdio.h>
//----------------------------------------------------------//
// Global Variables
unsigned char Name[64];
int Enter;
//----------------------------------------------------------//





//----------------------------------------------------------//
// Function to send character over USART
void USART_Send(unsigned char d)
{
	if(!HOLD)
	{
		while(!(USART_MODULE->SR&USART_SR_TC));										//wait for transmission complete
		USART_MODULE->DR=d;	
	} 
																			//write byte to usart data register
}
//----------------------------------------------------------//







//----------------------------------------------------------//
// Function to initalise USART 
void USART_init(void)
{
/*
	Bit 12 M: Word length
		This bit determines the word length. It is set or cleared by software.
			0: 1 Start bit, 8 Data bits, n Stop bit
			1: 1 Start bit, 9 Data bits, n Stop bit
			Note: The M bit must not be modified during a data transfer (both transmission and reception)

	Bit 10 PCE: Parity control enable
		This bit selects the hardware parity control (generation and detection). When the parity
		control is enabled, the computed parity is inserted at the MSB position (9th bit if M=1; 8th bit
		if M=0) and parity is checked on the received data. This bit is set and cleared by software.
		Once it is set, PCE is active after the current byte (in reception and in transmission).
			0: Parity control disabled
			1: Parity control enabled
	
	Bit 9 PS: Parity selection
		This bit selects the odd or even parity when the parity generation/detection is enabled (PCE
		bit set). It is set and cleared by software. The parity will be selected after the current byte.
			0: Even parity
			1: Odd parity
*/
	unsigned char i1,i2;
		SystemCoreClockUpdate();
		RCC->AHB1ENR|=RCC_AHB1ENR_GPIODEN;											//usart port clock enable
	
	USART_PORT->MODER&=~(																			//clear pin function bits
		(3u<<(2*USART_TX_pin))
		|(3u<<(2*USART_RX_pin))
			);
	USART_PORT->MODER|=(																			//reset pin function bits (alternate function)
		(2u<<(2*USART_TX_pin))
		|(2u<<(2*USART_RX_pin))
			);
	
	
	
	NVIC->ISER[1]|=(1u<<11);
	NVIC_EnableIRQ(USART3_IRQn); 
	
	i1=USART_TX_pin/8;
	i2=USART_RX_pin/8;

		// ALTERNATE FUNCTION SELECT BITS
	USART_PORT->AFR[i1]&=~(0x0f<<(4*(USART_TX_pin-(i1*8))));
	USART_PORT->AFR[i1]|=(0x07<<(4*(USART_TX_pin-(i1*8))));
	USART_PORT->AFR[i2]&=~(0x0f<<(4*(USART_RX_pin-(i2*8))));
	USART_PORT->AFR[i2]|=(0x07<<(4*(USART_RX_pin-(i2*8))));
	
	RCC->APB1ENR|=RCC_APB1ENR_USART3EN;												//usart clock enable
	USART_MODULE->CR1|=(																			//USART CONFIG
			USART_CR1_TE																					//transmit enable
			|USART_CR1_RE																					//receive enable
			|USART_CR1_UE																					//usart main enable bit
			|USART_CR1_RXNEIE																			//USART3 recieved data interrupt enable
//			|USART_CR1_PCE																				//Parity control enable
			|USART_CR1_PS																					//Parity selection
				);
	USART_MODULE->BRR=SystemCoreClock/BAUDRATE;								//set baud rate
	
	USART_ClearScreen();
	
	USART_SetCursor(1, 1);
	USART_putStr((unsigned char*)"Actual Voltage = ");
	
	USART_SetCursor(2, 1);
	USART_putStr((unsigned char*)"RMS Voltage = ");
	
	USART_SetCursor(3, 1);
	USART_putStr((unsigned char*)"Max Voltage = ");	
	
	USART_SetCursor(4, 1);
	USART_putStr((unsigned char*)"Min Voltage = ");	
	
	USART_SetCursor(5, 1);
	USART_putStr((unsigned char*)"Frequency = ");
	
	USART_SetCursor(6, 1);
	USART_putStr((unsigned char*)"Mode = Sine");
	
	USART_SetCursor(7, 1);
	USART_putStr((unsigned char*)"Console:");

	USART_SetCursor(8, 1);
	USART_putStr((unsigned char*)"Your Command:");	
}
//----------------------------------------------------------//








//----------------------------------------------------------//
// Function to send a string over USART
void USART_putStr(unsigned char* put) 											//sends a string to the LCD display
{
	int StrLen = USART_getStrLen(put);
	for(int i = 0; i < StrLen; i++)														//Used to input a char, convert into its Ascii
		{																												// and then position in array, and then outputted with LED
			USART_Send(put[i]);																		//Does this as many times as the length of the input string
		}		
}
//----------------------------------------------------------//









//----------------------------------------------------------//
// Function to get the length of a character array
int USART_getStrLen(unsigned char* put)
{
	for(int i = 0; i < 32; i++)
		{
			if(put[i] == '\0')
			{
				return i;																						//Find the length of the input string.																							//Once Lenght is found, exit loop
			}
		}
		return 0;
}
//----------------------------------------------------------//








//----------------------------------------------------------//
// USART3 Inturrupt service handler
void USART3_IRQHandler()
{
	unsigned int RX_int;
	unsigned char RX_char;
	static int Arr_Pos = 0;


	
  if(USART3->SR & USART_SR_RXNE)														//If RNXE bit in Register SR is high then 
  {	
		if((USART_MODULE->DR) == 0x0D)
			{
				Enter = 1;
				Arr_Pos = 0;
				USART_Mode_Update((const char*)RX_string);
				for(int j = 0; j<64; j++)
				{
					RX_string[j] = '\0';
				}
			} else {
				if(Arr_Pos >= 63)
				{
					for(int k = 9; k<64; k++)
					{
						RX_string[k] = 0x00;
					}
					RX_string[0] = 'O';
					RX_string[1] = 'v';
					RX_string[2] = 'e';
					RX_string[3] = 'r';
					RX_string[4] = 'f';
					RX_string[5] = 'l';
					RX_string[6] = 'o';
					RX_string[7] = 'w';
					RX_string[8] = '!';
				}
				RX_int = (USART_MODULE->DR);
				RX_int -= 0x30;
				RX_char = RX_int + '0';
				USART_MODULE->DR = 0;
				RX_string[Arr_Pos] = RX_char;
				Arr_Pos++;
				USART_SetCursor(8, Arr_Pos + 13);
				USART_Send(RX_char);
			}				
  }
}
//----------------------------------------------------------//







//----------------------------------------------------------//
void USART_ClearHelpList(void)
{
	USART_ClearLine(9, 1);
	USART_ClearLine(10, 1);
	USART_ClearLine(11, 1);
	USART_ClearLine(12, 1);
	USART_ClearLine(13,	1);
	USART_ClearLine(14, 1);
	USART_ClearLine(15, 1);
	USART_ClearLine(16, 1);
}

void USART_Mode_Update(const char* Str)
{
		USART_ClearLine(8, 14);
				if(strncmp((const char*)"Sine", (const char*)RX_string, (unsigned int)4) == 0)
				{
					MODE = 1;
					MAIN_Update_MODE();
				} else if(strncmp("Sawtooth", (const char*)RX_string, 8) == 0)
				{
					MODE = 2;
					MAIN_Update_MODE();
				} else if(strncmp("Triangle", (const char*)RX_string, 8) == 0)
				{
					MODE = 3;
					MAIN_Update_MODE();
				} else if(strncmp("Square", (const char*)RX_string, 6) == 0)
				{
					MODE = 4;
					MAIN_Update_MODE();
				} else if(strncmp("DC ", (const char*)RX_string, 2) == 0)
				{
					float digit1 = RX_string[5] - 0x30;
					float digit2 = RX_string[7] - 0x30;
					DC_Vol = ((digit1*10)+digit2)/10;					
					MODE = 0;
					MAIN_Update_MODE();
				} else if(strncmp("Refresh", (const char*)RX_string, 2) == 0)
				{
					MAIN_Refresh();
					if(USART_Help_Flag)
					{
						USART_ClearHelpList();
					}
					USART_ClearLine(7, 9);
					USART_SetCursor(7, 9);
					USART_putStr((unsigned char*)"All Values Refreshed");
				} else if(strncmp("Help", (const char*)RX_string, 4) == 0)
				{
					USART_Help_Flag = 1;
					USART_ClearLine(4, 9);
					
					USART_SetCursor(12, 1);
					USART_putStr((unsigned char*)"Vaild commands");
					
					USART_SetCursor(13, 3);
					USART_putStr((unsigned char*)"-- Sine");
					USART_SetCursor(13, 15);
					USART_putStr((unsigned char*)"// Change ADC");
					USART_putStr((unsigned char*)" output to Sine wave");
					
					USART_SetCursor(14, 3);
					USART_putStr((unsigned char*)"-- Sawtooth");
					USART_SetCursor(14, 15);
					USART_putStr((unsigned char*)"// Change ADC");
					USART_putStr((unsigned char*)" output to Sawtooth wave");
					
					USART_SetCursor(15, 3);
					USART_putStr((unsigned char*)"-- Square");
					USART_SetCursor(15, 15);
					USART_putStr((unsigned char*)"// Change ADC");
					USART_putStr((unsigned char*)" output to Square wave");
					
					USART_SetCursor(16, 3);
					USART_putStr((unsigned char*)"-- Triangle");
					USART_SetCursor(16, 15);
					USART_putStr((unsigned char*)"// Change ADC");
					USART_putStr((unsigned char*)" output to Trinagle wave");
					
					USART_SetCursor(17, 3);
					USART_putStr((unsigned char*)"-- DC");
					USART_SetCursor(17, 15);
					USART_putStr((unsigned char*)"// Change ADC");
					USART_putStr((unsigned char*)" output to DC output");
					
					USART_SetCursor(18, 3);
					USART_putStr((unsigned char*)"-- Refresh");
					USART_SetCursor(18, 15);
					USART_putStr((unsigned char*)"// Refresh MAX, MIN, ");
					USART_putStr((unsigned char*)"RMS and Fequency Values");
					
					USART_SetCursor(19, 3);
					USART_putStr((unsigned char*)"-- Help");
					USART_SetCursor(19, 15);
					USART_putStr((unsigned char*)"// List vaild commands");
				} else 
				{
					if(USART_Help_Flag)
					{
						USART_ClearHelpList();
					}
					USART_ClearLine(7, 9);
					USART_SetCursor(7, 9);
					USART_putStr((unsigned char*)"Unknown command ");
					USART_putStr((unsigned char*)", Type \"Help\" ");
					USART_putStr((unsigned char*)"for vaild commands.");
				}
				
}
//----------------------------------------------------------//









//----------------------------------------------------------//
// Function to reset the USART cursor back to original position using ASNI escape codes
void USART_ResetCursor(void)
{
	unsigned char* ASNI_Code = (unsigned char*)"\033[1;1H";
	USART_putStr(ASNI_Code);
}
//----------------------------------------------------------//









//----------------------------------------------------------//
// Function to set the USART cursor to X and Y paramaters using ASNI escape codes

void USART_SetCursor(int line, int col)
{	
	unsigned char ASNI_Code[9] = {0,0,0,0,0,0,0,0};
	int line1 = 0;
	int line2 = 0;
	int col1 = 0;
	int col2 = 0;
	if((line>9) && (col>9))
	{
		while(line>9)
		{
			line1++;
			line -= 10;
		}
		line2 = line;
		while(col>9)
		{
			col1++;
			col -= 10;
		}
		col2 = col;
		
		ASNI_Code[0] = 0x1B; // '\033'
		ASNI_Code[1] = 0x5B; // '['
		ASNI_Code[2] = line1 + '0';
		ASNI_Code[3] = line2 + '0';
		ASNI_Code[4] = ';';
		ASNI_Code[5] = col1 + '0';
		ASNI_Code[6] = col2 + '0';
		ASNI_Code[7] = 'H';
		ASNI_Code[8] = '\0';

		
		USART_putStr(ASNI_Code);
	} else if(line>9)
	{
				while(line>9)
		{
			line1++;
			line -= 10;
		}
		line2 = line;
		
		ASNI_Code[0] = 0x1B;
		ASNI_Code[1] = 0x5B;
		ASNI_Code[2] = line1 + '0';
		ASNI_Code[3] = line2 + '0';
		ASNI_Code[4] = ';';
		ASNI_Code[5] = col + '0';
		ASNI_Code[6] = 'H';
		ASNI_Code[7] = '\0';
		ASNI_Code[8] = '\0';
		
		USART_putStr(ASNI_Code);
	} else if(col>9)
	{
				while(col>9)
		{
			col1++;
			col -= 10;
		}
		col2 = col;
		
		ASNI_Code[0] = 0x1B;
		ASNI_Code[1] = 0x5B;
		ASNI_Code[2] = line + '0';
		ASNI_Code[3] = ';';
		ASNI_Code[4] = col1 + '0';
		ASNI_Code[5] = col2 + '0';
		ASNI_Code[6] = 'H';
		ASNI_Code[7] = '\0';
		ASNI_Code[8] = '\0';
		
		USART_putStr(ASNI_Code);
	} else
	{
		ASNI_Code[0] = 0x1B;
		ASNI_Code[1] = 0x5B;
		ASNI_Code[2] = line + '0';
		ASNI_Code[3] = ';';
		ASNI_Code[4] = col + '0';
		ASNI_Code[5] = 'H';
		ASNI_Code[6] = '\0';
		ASNI_Code[7] = '\0';
		ASNI_Code[8] = '\0';	
		
		USART_putStr(ASNI_Code);
	}
}
//----------------------------------------------------------//








//----------------------------------------------------------//
// Function to clear USART screen using ASNI escape codes
void USART_ClearScreen(void)
{
	unsigned char* MoveCur = (unsigned char*)"\033[2J";
	USART_putStr(MoveCur);
	USART_ResetCursor();
}
//----------------------------------------------------------//





//----------------------------------------------------------//
// Function to clear USART screen using ASNI escape codes
void USART_ClearLine(int line, int pos)
{
	unsigned char* MoveCur = (unsigned char*)"\033[K";
	USART_SetCursor(line, pos);
	USART_putStr(MoveCur);
	USART_SetCursor(line, pos);
}
//----------------------------------------------------------//







//----------------------------------------------------------//
// Function to move cursor up using ASNI escape codes
void USART_MoveUp(int MoveAmount)
{
	for(int i = 0; i<MoveAmount; i++)
	{
		unsigned char* ASNI_Code = (unsigned char*)"\033[1A";
		USART_putStr(ASNI_Code);
	}
}
//----------------------------------------------------------//






//----------------------------------------------------------//
// Function to move cursor down using ASNI escape codes
void USART_MoveDown(int MoveAmount)
{
	for(int i = 0; i<MoveAmount; i++)
	{
		unsigned char* ASNI_Code = (unsigned char*)"\033[1B";
		USART_putStr(ASNI_Code);
	}
}
//----------------------------------------------------------//







//----------------------------------------------------------//
// Function to move cursor right using ASNI escape codes
void USART_MoveRight(int MoveAmount)
{
	for(int i = 0; i<MoveAmount; i++)
	{
		unsigned char* ASNI_Code = (unsigned char*)"\033[1C";
		USART_putStr(ASNI_Code);
	}
}
//----------------------------------------------------------//







//----------------------------------------------------------//
// Function to move cursor left using ASNI escape codes
void USART_MoveLeft(int MoveAmount)
{
	for(int i = 0; i<MoveAmount; i++)
	{
		unsigned char* ASNI_Code = (unsigned char*)"\033[1D";
		USART_putStr(ASNI_Code);
	}
}
//----------------------------------------------------------//







//----------------------------------------------------------//
// Function to draw a graph over USART
void USART_DrawGraph(int Rows, int Cols)
{
	USART_ClearScreen();
	USART_putStr((unsigned char*)"SineWave");
	for(int i  = 1; i<Rows+1; i++)
	{
		USART_SetCursor(i+1, 4);
		USART_Send('|');
	}
	USART_SetCursor(Rows+2, 3);
	USART_putStr((unsigned char*)"0|");
	USART_SetCursor((Rows+2)-5, 1);
	USART_putStr((unsigned char*)"0.5");
	USART_SetCursor((Rows+2)-10, 1);
	USART_putStr((unsigned char*)"1.0");
	USART_SetCursor((Rows+2)-15, 1);
	USART_putStr((unsigned char*)"1.5");
	USART_SetCursor((Rows+2)-20, 1);
	USART_putStr((unsigned char*)"2.0");
	USART_SetCursor((Rows+2)-25, 1);
	USART_putStr((unsigned char*)"2.5");
	USART_SetCursor((Rows+2)-30, 1);
	USART_putStr((unsigned char*)"3.0");
	USART_SetCursor((Rows+2)-33, 1);
	USART_putStr((unsigned char*)"3.3");
	USART_SetCursor((Rows+2)-35, 1);
	USART_putStr((unsigned char*)"3.5");
	USART_SetCursor(Rows+2, 3);
	for(int i = 4; i<Cols+5; i++)
	{
		USART_SetCursor(Rows+3, i);
		USART_Send('-');
	}
	USART_SetCursor(39, 1);
	USART_putStr((unsigned char*)"Voltage = ");
	USART_SetCursor(40, 1);
	USART_putStr((unsigned char*)"RMS Voltage = ");
}
//----------------------------------------------------------//






//----------------------------------------------------------//
// Function to update graph with an array of floats
void USART_UpdateGraphArray(float* Data)
{
	for(int i = 0; i<64; i++)
	{
		USART_SetCursor(37 - (Data[i]*10), i+5);
		USART_Send('+');
	}
}
//----------------------------------------------------------//







//----------------------------------------------------------//
// Function to update graph with a single value and increment the position index
void USART_UpdateGraphSingle(float Data)
{
	static float GraphArray[64];
	static int index = 0;
	if(GraphArray[index] != Data)
	{
		USART_SetCursor(37 - (GraphArray[index]*10), index+5);
		USART_Send(' ');
		USART_SetCursor(37 - (Data*10), index+5);
		USART_Send('+');
		GraphArray[index] = Data;
	}
	index++;
	if(index > 65){index = 0;}
}
//----------------------------------------------------------//






//----------------------------------------------------------//
// Function to update actual voltage read-out on USART terminal
void USART_putVolt(float Data)
{
	USART_SetCursor(1, 18);
	USART_FloatToChar(Data);
}
//----------------------------------------------------------//




//----------------------------------------------------------//
// Function to update RMS voltage read-out on USART terminal
void USART_putRMS(float Data)
{
	USART_SetCursor(2, 15);
	USART_FloatToChar(Data);
}
//----------------------------------------------------------//




//----------------------------------------------------------//
// Function to update RMS voltage read-out on USART terminal
void USART_putMAX(float Data)
{
	USART_SetCursor(3, 15);
	USART_FloatToChar(Data);
}
//----------------------------------------------------------//




//----------------------------------------------------------//
// Function to update RMS voltage read-out on USART terminal
void USART_putMIN(float Data)
{
	USART_SetCursor(4, 15);
	USART_FloatToChar(Data);
}
//----------------------------------------------------------//




//----------------------------------------------------------//
// Function to update RMS voltage read-out on USART terminal
void USART_putFREQ(float Data)
{
	USART_SetCursor(5, 13);
	USART_FloatToChar(Data);
}
//----------------------------------------------------------//




//----------------------------------------------------------//
// Function to display float on USART termianl
void USART_FloatToChar(float data)
{
	char ThouChar;
	char HundChar;
	char TenChar;
	char OneChar;
	int Thou = 0;
	int Hund = 0;
	int Tens = 0;
	int Ones = 0;
	int put = data * 1000;
	unsigned char* Float_Char_Array;
	for(int i = 0;put>=1000;i++)
	{
		Thou++;
		put -=1000;
	}
	for(int i = 0;put>=100;i++)
	{
		Hund++;
		put -=100;
	}
	for(int i = 0;put>=10;i++)
	{
		Tens++;
		put -=10;
	}
	for(int i = 0;put>=1;i++)
	{
		Ones++;
		put -=1;
	}
	ThouChar = Thou + '0';
	Float_Char_Array[0] = ThouChar;
	HundChar = Hund + '0';
	Float_Char_Array[1] = '.';
	Float_Char_Array[2] = HundChar;
	TenChar = Tens + '0';
	Float_Char_Array[3] = TenChar;
	OneChar = Ones + '0';
	Float_Char_Array[4] = OneChar;
	Float_Char_Array[5] = '\0';
	
	USART_putStr(Float_Char_Array);
}
//----------------------------------------------------------//




//----------------------------------------------------------//
// Function to display float on USART termianl
void USART_IntToChar(int data)
{
//	char ThouChar;
//	char HundChar;
//	char TenChar;
//	char OneChar;
//	int Thou = 0;
//	int Hund = 0;
//	int Tens = 0;
//	int Ones = 0;
//	int put = data;
	char* Int_Char_Array;
//	for(int i = 0;put>=1000;i++)
//	{
//		Thou++;
//		put -=1000;
//	}
//	for(int i = 0;put>=100;i++)
//	{
//		Hund++;
//		put -=100;
//	}
//	for(int i = 0;put>=10;i++)
//	{
//		Tens++;
//		put -=10;
//	}
//	for(int i = 0;put>=1;i++)
//	{
//		Ones++;
//		put -=1;
//	}
//	ThouChar = Thou + '0';
//	Int_Char_Array[0] = ThouChar;
//	HundChar = Hund + '0';
//	Int_Char_Array[1] = HundChar;
//	TenChar = Tens + '0';
//	Int_Char_Array[2] = TenChar;
//	OneChar = Ones + '0';
//	Int_Char_Array[3] = OneChar;
//	Int_Char_Array[4] = '\0';
	sprintf(Int_Char_Array,"%d", data);
	USART_putStr((unsigned char*)Int_Char_Array);
}
//----------------------------------------------------------//

float USART_CharArrToFloat(unsigned char Data[3])
{
	int int1 = 0;
	int int2 = 0;
	float ReturnFloat = 0;
	int1 = Data[0] - '0';
	int2 = Data[2] - '0';
	ReturnFloat = ((int1*10)+int2)/10;
	if(ReturnFloat > 3.3f)
	{
		ReturnFloat = 3.3f;
	} else if(ReturnFloat < 0.0f)
	{
		ReturnFloat = 0;
	}
	return ReturnFloat;
}

void USART_Analog_Rep(unsigned short Voltage)
{
	USART_ClearLine(11, 1);
	int Analog_Dis_Count = 0;
	while(Voltage>=512)
	{
		Analog_Dis_Count += 1;
		Voltage -= 512;
		USART_SetCursor(11, Analog_Dis_Count);
		USART_Send('+');
	}
	USART_SetCursor(12, 1);
}
//----------------------------------------------------------//

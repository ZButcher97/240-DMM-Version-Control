#ifndef _DAC_H
#define _DAC_H
#include <stm32f4xx.h>

#define DAC_port	GPIOA
#define DAC_pin		5


void DAC_init(void);
void DAC_Output(unsigned short d);
void DAC_SendVoltage(float DAC_Voltage);
void DAC_DC_Output(float Voltage);

#endif

#include "LED.h"
//----------------------------------------------------------//
// Global Variables
const int LED_MorseLookUp[36][6] = {				  							//Look up table for morse code to characters
	{1,3,0,0,0} ,	//0 = A																			//1 = dot, 3 = dash
	{3,1,1,1,0} ,	//1 = B
	{3,1,3,1,0} ,	//2 = C
	{3,1,1,0,0} ,	//3 = D
	{1,0,0,0,0} ,	//4 = E
	{1,1,3,1,0} ,	//5 = F
	{3,3,1,0,0} ,	//6 = G
	{1,1,1,1,0} ,	//7 = H
	{1,1,0,0,0} ,	//8 = I
	{1,3,3,3,0} ,	//9 = J
	{3,1,3,0,0} ,	//10 = K
	{1,3,1,1,0} ,	//11 = L
	{3,3,0,0,0} ,	//12 = M
	{3,1,0,0,0} ,	//13 = N
	{3,3,3,0,0} ,	//14 = O
	{1,3,3,1,0} ,	//15 = P
	{3,3,1,3,0} ,	//16 = Q
	{1,3,1,0,0} ,	//17 = R
	{1,1,1,0,0} ,	//18 = S
	{3,0,0,0,0} ,	//19 = T
	{1,1,3,0,0} ,	//20 = U
	{1,1,1,3,0} ,	//21 = V
	{1,3,3,0,0} ,	//22 = W
	{3,1,1,3,0} ,	//23 = X
	{3,1,3,3,0} ,	//24 = Y
	{3,3,1,1,0} ,	//25 = Z
	{3,3,3,3,3,0}	,	//26 = 0
	{1,3,3,3,3,0} ,	//27 = 1
	{1,1,3,3,3,0} ,	//28 = 2
	{1,1,1,3,3,0} ,	//29 = 3
	{1,1,1,1,3,0} ,	//30 = 4
	{1,1,1,1,1,0} ,	//31 = 5
	{3,1,1,1,1,0} ,	//32 = 6
	{3,3,1,1,1,0} ,	//33 = 7
	{3,3,3,1,1,0} ,	//34 = 8
	{3,3,3,3,1,0} 	//35 = 9
};
//----------------------------------------------------------//






//----------------------------------------------------------//
// Blocking fucntion in mS
void LED_delay_ms_blocking(unsigned int ms)
{
	unsigned int i;																						//increment a variable to waste time
	unsigned int j;
	
	for(i=0;i<=ms;i++)
	{
		for(j=0; j<SystemCoreClock/18000; j++);									//incrementing a variable from 0 to 450,000,000 takes 1ms when MCU speed is 180MHz
	}
}
//----------------------------------------------------------//






//----------------------------------------------------------//
// Function to initalise onboard LEDs
void LED_init (void)
{
	//OTYPER, OSPEEDR, PUPDR. 
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;											//ENABLE PORT(S), ONLY GPIO B clock enable
	
																														//CONFIGURE PORT:GPIOB  PIN:0 TO OUTPUT for Green LED,
																														//PIN:7 TO OUTPUT for Blue LED, PIN:14 TO OUTPUT Red LED
	LED_Port->MODER&=~(																				//ONLY reset  GPIOB0/1, GPIOB14/15 & GPIOB28/29
								(3u<<(2*Green_LED_Pin))
								|(3u<<(2*Red_LED_Pin))
								|(3u<<(2*Blue_LED_Pin))
								);
	LED_Port->MODER |=(																				//ONLY set GPIOB0, GPIOB14 & GPIOB28. 
								(1u<<(2*Green_LED_Pin))											// Remember there are 2 bits per pin in the MODE Register(MODER)
								|(1u<<(2*Red_LED_Pin))
								|(1u<<(2*Blue_LED_Pin))
								);
	
	LED_Port->OTYPER&=~(																			//Resets LED pins output type to 0b, 0b is push pull		
								(1u<<(Green_LED_Pin))											
								|(1u<<(Red_LED_Pin))
								|(1u<<(Blue_LED_Pin))
								);
								
								
	LED_Port->OSPEEDR&=~(																			//Resets LED pins output speed to 00b, 00b is low speed						
								(3u<<(2*Green_LED_Pin))											
								|(3u<<(2*Red_LED_Pin))
								|(3u<<(2*Blue_LED_Pin))
								);
								
	LED_Port->PUPDR&=~(																				//Resets LED pins pull up/pull down type to 00b, 00b is no pull up/pull down
								(3u<<(2*Green_LED_Pin))											
								|(3u<<(2*Red_LED_Pin))
								|(3u<<(2*Blue_LED_Pin))
								);
	
}	
//----------------------------------------------------------//






//----------------------------------------------------------//
// Function to return array position of MorseArray for character passed
int LED_FindChar(char Input)
{
	int Character = Input;
	if((Character>=0x41)&&(Character<=0x5A))									//Tests for inbetween A and Z on Ascii table
	{
		return (Character-0x41);																//Takes away ASCII hex of A(0x41), so A would = 0,
	}																													// which relates the to position in the morse look up array
	else if((Character>=0x30)&&(Character<=0x39))							//Tests for inbetween 0 and 9 on Ascii table
	{
		return (Character-0x16);
	}
	else if((Character>=0x61)&&(Character<=0x7A))							//Tests for inbetween a and z on Ascii table
	{
		return (Character-0x61);
	}
		
	return 1;																									//if an invalid character is entered, returns 1
}
//----------------------------------------------------------//






//----------------------------------------------------------//
// Funcion to send character in morse to selected LED
void LED_SendChar(int Pos, int LED)
{
	if(Pos == 1)																							//if Pos=1, invalid character was entered
	{																													// and returns from function, skipping this character
		return;
	}
	for(int i = 0; i<=5; i++)
	{
		if(LED_MorseLookUp[Pos][i] == 0)
		{
			LED_delay_ms_blocking(Unit*3);												//delay between characters
			return;																								//end of the character
		}
		
		if(LED == 0)
		{
			LED_Set_Green();
			LED_delay_ms_blocking(Unit*LED_MorseLookUp[Pos][i]);	//1 unit time is preset, then multiplied by lookup array
			LED_Rst_Green();
			LED_delay_ms_blocking(Unit);													//delay_ms_blocking between dots and dashes of same character
		}
		else if(LED == 1)
		{
			LED_Set_Red();
			LED_delay_ms_blocking(Unit*LED_MorseLookUp[Pos][i]);	//1 unit time is preset, then multiplied by lookup array
			LED_Rst_Red();	
			LED_delay_ms_blocking(Unit);													//delay_ms_blocking between dots and dashes of same character
		}
		else if (LED == 2)
		{
  		LED_Set_Blue();
			LED_delay_ms_blocking(Unit*LED_MorseLookUp[Pos][i]);	//1 unit time is preset, then multiplied by lookup array
			LED_Rst_Blue();
			LED_delay_ms_blocking(Unit);													//delay_ms_blocking between dots and dashes of same character
		}
		else 
		{
			LED_Set_Green();
			LED_delay_ms_blocking(Unit*LED_MorseLookUp[Pos][i]);	//1 unit time is preset, then multiplied by lookup array
			LED_Rst_Green();
			LED_delay_ms_blocking(Unit);													//delay_ms_blocking between dots and dashes of same character
		}
	}
}
//----------------------------------------------------------//






//----------------------------------------------------------//
// Function to return length of character array
int LED_StrLen(unsigned char* String)
{
	int StrLength = 0;
		for(int i = 0; i < 32; i++)
		{
			if(String[i] == '\0')
			{
				StrLength = i;																			//Find the length of the input string.
				break;																							//Once Lenght is found, exit loop
			}
		}
		return StrLength;
}
//----------------------------------------------------------//






//----------------------------------------------------------//
// Funcion to send string in morse to selected LED
void LED_Morse_SendStr(unsigned char* String, int LED)
{
	int StrLength = LED_StrLen(String);
		for(int i = 0; i < StrLength; i++)										//Used to input a char, convert into its Ascii
		{																												// and then position in array, and then outputted with LED
			LED_SendChar(LED_FindChar(String[i]), LED);						//Does this as many times as the length of the input string
		}																												// and selects led to output morse
		LED_delay_ms_blocking(4*Unit); 													//Delay between words is 7 but 3 are happening in
}
//----------------------------------------------------------//

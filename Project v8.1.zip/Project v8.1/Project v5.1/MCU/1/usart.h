#ifndef _USART_H_
#define _USART_H_
#include <stm32f4xx.h>

#define USART_MODULE	USART3
#define USART_PORT		GPIOD
#define USART_TX_pin	8
#define USART_RX_pin	9
#define USART_RXNE_bit 5
#define BAUDRATE			115200


void USART_Send(unsigned char d);
void USART_init(void);
void USART_putStr(unsigned char put[]);
int USART_getStrLen(unsigned char put[]);
void USART_ResetCursor(void);
void USART_SetCursor(int line, int col);
void USART_ClearScreen(void);
void USART_ClearLine(int line, int pos);
void USART_MoveUp(int MoveAmount);
void USART_MoveDown(int MoveAmount);
void USART_MoveRight(int MoveAmount);
void USART_MoveLeft(int MoveAmount);
void USART_DrawGraph(int Rows, int Cols);
void USART_UpdateGraphArray(float* Data);
void USART_UpdateGraphSingle(float Data);
void USART_putVolt(float Data);
void USART_putRMS(float Data);
void USART_putMAX(float Data);
void USART_putMIN(float Data);
void USART_putFREQ(float Data);
void USART_FloatToChar(float data);
void USART_IntToChar(int data);
void USART_ClearHelpList(void);
void USART_Mode_Update(const char* Str);
void USART_Analog_Rep(unsigned short Voltage);

float USART_CharArrToFloat(unsigned char Data[3]);

extern void MAIN_Update_MODE(void);

extern unsigned char RX_string[64];
extern int MODE; 
extern int HOLD;
static int USART_Help_Flag = 0;
extern void MAIN_Refresh(void);
extern float DC_Vol;

#endif

#ifndef _LED_H_
#define _LED_H_
#include <stm32f4xx.h>																			//INCLUDE THE HEADER FILE FOR THIS MCU FAMILY																														
																		//this file contains the definitions for register addresses and values etc...

#define LED_Port GPIOB
#define Green_LED_Pin 0
#define Blue_LED_Pin 7
#define Red_LED_Pin 14


#define LED_Set_Green()	LED_Port->BSRR=(1u<<Green_LED_Pin)
#define LED_Rst_Green()	LED_Port->BSRR=(1u<<(Green_LED_Pin+16))
#define LED_Tog_Green() LED_Port->ODR^=(1u<<Green_LED_Pin)

#define LED_Set_Red()	LED_Port->BSRR=(1u<<Red_LED_Pin)
#define LED_Rst_Red()	LED_Port->BSRR=(1u<<(Red_LED_Pin+16))
#define LED_Tog_Red() LED_Port->ODR^=(1u<<Red_LED_Pin)

#define LED_Set_Blue()	LED_Port->BSRR=(1u<<Blue_LED_Pin)
#define LED_Rst_Blue()	LED_Port->BSRR=(1u<<(Blue_LED_Pin+16))
#define LED_Tog_Blue()	LED_Port->ODR^=(1u<<Blue_LED_Pin)


#define Unit 200

void LED_delay_ms_blocking(unsigned int ms);
void LED_init (void);
int LED_FindChar(char Input);
void LED_SendChar(int Pos, int LED);
int LED_StrLen(unsigned char* String);
void LED_Morse_SendStr(unsigned char* String, int LED);

#endif

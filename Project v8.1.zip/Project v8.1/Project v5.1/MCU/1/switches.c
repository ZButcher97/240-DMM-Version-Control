#include "switches.h"

/*
design for interrupt on a rising edge and combat switch bounce, start timer, interrupt on a falling edge and combat switch bounce,
stop timer, read timer length and decide action to take depending on the length the switch was held for
*/
//----------------------------------------------------------//
void TIMER_init_ButtonInterrupt(void)
{
	//Button Interrupt Init
	RCC->AHB1ENR|=RCC_AHB1ENR_GPIOCEN;		//GPIO C clock enable
	RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;  //turn clock on 
	Button_Port->MODER&=~(																			
								(3u<<(2*Button_Pin))									//00 in MODER register it default value and is Input state
								);
		Button_Port->OTYPER&=~(																			
								(1u<<(Button_Pin))										//0 in OTYPER register it default value and is Output Push-Pull state
								);
		Button_Port->OSPEEDR&=~(																			
								(3u<<(2*Button_Pin))									//00 in OSPEEDR register it default value and is low speed
								);
		Button_Port->PUPDR&=~(																			
								(3u<<(2*Button_Pin))									//00 in PUPDR register it default value and is no pull up pull down
								);
	SYSCFG->EXTICR[3] |= (2<<4);              // EXTI4 set to Port C
	EXTI->IMR |= (1 << 13);                  // unmask EXTI13 interrupt - pin 13
  EXTI->RTSR |= (1 << 13);                 // rising edge
	NVIC_EnableIRQ(EXTI15_10_IRQn);					//enable EXTI15-10 for EXIT 13 interrupt
}
//----------------------------------------------------------//

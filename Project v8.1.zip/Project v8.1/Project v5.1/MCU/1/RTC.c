#include "RTC.h"

void RTC_WrtAccess(void)
{
	RTC->WPR = RTC_Key1;
	RTC->WPR = RTC_Key2;
}

void RTC_init(void)
{
	RTC->ISR |= RTC_ISR_INIT; //Set initalisation bit
	while(((RTC->ISR)&(RTC_ISR_INITF)) == 0); //Poll INITF bit until bit == 1
	RTC->PRER = 0; //sychronous
	RTC->PRER = 0; //asychronous
	RTC->TR = 0; //inital time
	RTC->DR = 0; //inital date
	RTC->CR |= (1<<6); //FMT bit to set the format, 12 or 24 hour
	RTC->ISR &=~ RTC_ISR_INIT;	//clear initalisation bit
	RTC->CR |= RTC_CR_BYPSHAD;	//Read comes directly from calander, not from shadow registers.
	//RTC->CR &=~ RTC_CR_BYPSHAD;	//Read comes from shadow register, not directly from calander
}

float RTC_ReadTime(void)
{
	//Below line only needed if the BYPSHAD bit in CR register is NOT set
	//while(((RTC->ISR)&(RTC_ISR_RSF)) == 0); //"To read the calendar after initialization, the software must first check that the RSF flag is set in the RTC_ISR register" pg805
	int TIME_Secs = (RTC->TR & 0x7f);	//read register and set time variable to the tens and ones seconds
	return TIME_Secs;
} 

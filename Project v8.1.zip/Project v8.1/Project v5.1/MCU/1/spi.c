#include "spi.h"
//----------------------------------------------------------//
// Function to transfer and return data over SPI
unsigned short SPI_transfer(unsigned short send_val)
{
	unsigned char return_val;
	clr_CS();
	SPI1->DR=send_val;
	while((SPI1->SR&0x81)!=0x01);															//wait while BSY bit set and RXNE bit clear,
	return_val=SPI1->DR;																			//	when BSY bit clears spi bus is no longer busy, 
	set_CS();																													//		when valid data arrives in the buffer RXNE bit sets	
	return return_val;
}
//----------------------------------------------------------//



//----------------------------------------------------------//
// Function to initalise SPI ports
void SPI_init_ports(void)
{
	RCC->AHB1ENR|=(RCC_AHB1ENR_GPIOAEN|RCC_AHB1ENR_GPIOBEN);	//GPIO A,B clock enable
	
			//CONFIG GPIOS
	CS_PORT->MODER&=~((3u<<(2*CS_pin)));											//clear GPIOA pin mode
	CS_PORT->MODER|=((1u<<(2*CS_pin)));												//reset GPIOA pin mode to digital output
	
	SPI_PORT->MODER&=~(																				//clear GPIOB 0,3,4,5 pin modes
			(3u<<(2*SCK_pin))
			|(3u<<(2*MISO_pin))
			|(3u<<(2*MOSI_pin))
			|0x03
				);
	SPI_PORT->MODER|=(																				//reset GPIOB pins 3,4,5 mode to alternate function,
			(2u<<(2*SCK_pin))																			//	 pin 0 to digital output
			|(2u<<(2*MISO_pin))
			|(2u<<(2*MOSI_pin))
			|0x01
				);
	SPI_PORT->AFR[0]&=~(																			//clear alternate function selector bits
			(0x0f<<(4*SCK_pin))
			|(0x0f<<(4*MISO_pin))
			|(0x0f<<(4*MOSI_pin))
				);
	SPI_PORT->AFR[0]|=(																				//reset alternate function selector bits to SPI1
			(5u<<(4*SCK_pin))
			|(5u<<(4*MISO_pin))
			|(5u<<(4*MOSI_pin))
				);
				
		set_CS();
}
//----------------------------------------------------------//



//----------------------------------------------------------//
// Function to initalise SPI
void SPI_init(void)
{
	SPI_init_ports();
	/*
	SPI1->CR1
	Bit 11 DFF: Data frame format
		0: 8-bit data frame format is selected for transmission/reception
		1: 16-bit data frame format is selected for transmission/reception
			Note: This bit should be written only  when SPI is disabled (SPE = �0�) for correct operation.
						It is not used in I2S mode.
	*/
				//CONFIG SPI MODULE
	RCC->APB2ENR|=RCC_APB2ENR_SPI1EN;
	SPI1->CR1&=~(																							//module disabled, clear bad rate bits
			SPI_CR1_SPE
			|SPI_CR1_BR
				);
	SPI1->CR1|=(																							//spi config
			SPI_CR1_SSI
			|SPI_CR1_DFF																					//Data frame format set to 16 bit
			|SPI_CR1_SSM																					//SS control set
			|SPI_CR1_MSTR																					//master mode
			|SPI_CR1_SPE																					//module enabled
			|(3u<<3)																							//baud rate bits set /16 giving 1MHz SCK frequency
				);
}
//----------------------------------------------------------//



//----------------------------------------------------------//

unsigned short SPI_Send_Voltage(unsigned short Voltage)
{
	int TX_DATA = 0;							//final word to send over SPI
	int LED_Select = 0;						//Var to store LED selected depending on voltage
	int Voltage_PWM_Val = 0;			//Var to store the PWM duty cycle depending on voltage
	
	if(Voltage>4096)							//upper lim @4096
	{
		Voltage = 4096;
	}
	
	int LED_Buf = Voltage;				//buffer
	int Voltage_Buf = Voltage;		//buffer
	
	while(LED_Buf >= 512)					//2^3 = 8, 4096/8 = 512
	{
		LED_Select += 1;
		LED_Buf -= 512;
	}
	
	Voltage_Buf -= LED_Select*512;
	
	while(Voltage_Buf>8)					//2^9 = 512, 4096/512 = 8
	{
		Voltage_PWM_Val += 1;
		Voltage_Buf -= 8;
	}
	
	TX_DATA |= Voltage_PWM_Val<<0;		//bit shift Vars into correct positions in TX_DATA
	TX_DATA |= LED_Select<<9;
	
	
	if(Voltage_PWM_Val >=32)
	{
		TX_DATA |= (1<<15);
	} else 
	{
		TX_DATA &=~ (1<<15);
	}
	
	return SPI_transfer(TX_DATA);			//Send data
}
//----------------------------------------------------------//

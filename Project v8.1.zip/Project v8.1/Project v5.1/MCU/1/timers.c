#include "timers.h"
/*
PWM Mode 
pg. 541
TIM1 and TIM8

RCC TIM regs:
APB1 TIMER - 14, 13, 12, 7, 6, 5, 4, 3, 2
APB2 TIMER - 11, 10, 9, 8, 1

NVIC TIM numbers
TIM1 Break Interrupt 24
TIM1 Update Interrupt 25
TIM1 Trigger and Communtation interrupt 26
TIM1 Capture Compare interrupt 27
TIM2 Global interrupt 28
TIM3 Global interrupt 29
TIM4 Global interrupt 30
TIM5 Global interurpt 50
TIM6 Global interurpt 54
TIM7 Global interurpt 55
TIM8 Break Interrupt 43
TIM8 Update Interrupt 44
TIM8 Trigger and Communtation interrupt 45
TIM8 Capture Compare interrupt 46
TIM9 Global interrupt 24
TIM10 Global interrupt 25
TIM11 Global interrupt 26

Advanced Timers - 1, 8
General Purpose Timers - 2, 3, 4, 5, 9, 10, 11, 12, 13, 14
Basic Timers - 6, 7

32bit Timers - 2, 5
16bit Timers - All other timers

4 Channel Timers - 1, 2, 3, 4, 5, 8
2 Channel Timers - 9, 12
1 Channel Timers - 10, 11, 13, 14
0 Channel Timers - 6, 7

*/
//----------------------------------------------------------//
// Function to initiate Timer 4 with variable PSC and ARR values
void TIMER_init_Tim1(int PSC, float ARR) //16 bit max ARR 65536
{
	RCC->APB2ENR|=RCC_APB2ENR_TIM1EN;
	TIM1->DIER|=TIM_DIER_UIE;
	TIM1->PSC=PSC-1;																					//divide APB clock by 256 = 90MHz/256 = 351kHz
	TIM1->ARR = ARR;
	TIM1->CNT=0;
	NVIC->ISER[0]|=(1u<<26);
	TIMER_TIM1_Enable;
}
//----------------------------------------------------------//



//----------------------------------------------------------//
// Function to initiate Timer 2 with variable PSC and ARR values
void TIMER_init_Tim2(int PSC, float ARR)
{
	RCC->APB1ENR|=RCC_APB1ENR_TIM2EN;													//timer 2 clock enabled
	TIM2->DIER|=TIM_DIER_UIE;																	//timer uptdate interrupt enabled
	
	
	
																														//APB clock is Fcy/2 = 180MHz/2 = 90MHz
//TIM2->PSC=256-1;
	TIM2->PSC=PSC-1;																					//divide APB clock by 256 = 90MHz/256 = 351kHz
	TIM2->ARR = ARR;
//TIM2->ARR=65535;																					//counter reload value, gives a timer period of 100ms when F_APB = 90MHz and PSC = 256
//TIM2->ARR=250;																						//ARR = (F_APB/(PSC+1))*T_Delay
																														//ARR = (90,000,000/256)*0.1 = 35,156.25 rounded 35156
	TIM2->CNT=0;																							//zero timer counter
	NVIC->ISER[0]|=(1u<<28);																	//timer 2 global interrupt enabled (1u<<28) corresponds to TIM2, (1u<<29) for TIM3, (1u<<30) for TIM4
	
	TIMER_TIM2_Enable;																				//start timer counter	
}
//----------------------------------------------------------//



//----------------------------------------------------------//
// Function to initiate Timer 3 with variable PSC and ARR values
void TIMER_init_Tim3(int PSC, float ARR)
{
	RCC->APB1ENR|=RCC_APB1ENR_TIM3EN;
	TIM3->DIER|=TIM_DIER_UIE;
	
	
	TIM3->PSC=PSC-1;																					//divide APB clock by 256 = 90MHz/256 = 351kHz
	TIM3->ARR = ARR;

	
	TIM3->CNT=0;
	NVIC->ISER[0]|=(1u<<29);
	NVIC_SetPriority(TIM3_IRQn,1);
	TIMER_TIM3_Enable;
}
//----------------------------------------------------------//



//----------------------------------------------------------//
// Function to initiate Timer 4 with variable PSC and ARR values
void TIMER_init_Tim4(int PSC, float ARR)
{
	RCC->APB1ENR|=RCC_APB1ENR_TIM4EN;
	TIM4->DIER|=TIM_DIER_UIE;
	TIM4->PSC=PSC-1;																					//divide APB clock by 256 = 90MHz/256 = 351kHz
	TIM4->ARR = ARR;
	TIM4->CNT=0;
	NVIC->ISER[0]|=(1u<<30);
	//TIMER_TIM4_Enable;
}
//----------------------------------------------------------//



//----------------------------------------------------------//
// Function to initiate Timer 4 with variable PSC and ARR values
void TIMER_init_Tim5(int PSC, float ARR)
{
	RCC->APB1ENR|=RCC_APB1ENR_TIM5EN;
	TIM5->DIER|=TIM_DIER_UIE;
	TIM5->PSC=PSC-1;																					//divide APB clock by 256 = 90MHz/256 = 351kHz
	TIM5->ARR = ARR;
	TIM5->CNT=0;
	NVIC->ISER[1]|=(1u<<18);
	//TIMER_TIM5_Enable;
}
//----------------------------------------------------------//



//----------------------------------------------------------//
// Function to initiate Timer 4 with variable PSC and ARR values
void TIMER_init_Tim6(int PSC, float ARR)
{
	RCC->APB1ENR|=RCC_APB1ENR_TIM6EN;
	TIM6->DIER|=TIM_DIER_UIE;
	TIM6->PSC=PSC-1;																					//divide APB clock by 256 = 90MHz/256 = 351kHz
	TIM6->ARR = ARR;
	TIM6->CNT=0;
	NVIC->ISER[1]|=(1u<<23);
	TIMER_TIM6_Enable;
}
//----------------------------------------------------------//



//----------------------------------------------------------//
// Function to initiate Timer 4 with variable PSC and ARR values
void TIMER_init_Tim7(int PSC, float ARR)
{
	RCC->APB1ENR|=RCC_APB1ENR_TIM7EN;
	TIM7->DIER|=TIM_DIER_UIE;
	TIM7->PSC=PSC-1;																					//divide APB clock by 256 = 90MHz/256 = 351kHz
	TIM7->ARR = ARR;
	TIM7->CNT=0;
	NVIC->ISER[1]|=(1u<<23);
	//TIMER_TIM7_Enable;
}
//----------------------------------------------------------//



//----------------------------------------------------------//
// Function to initiate Timer 4 with variable PSC and ARR values
void TIMER_init_Tim8(int PSC, float ARR) //16bit
{
	RCC->APB2ENR|=RCC_APB2ENR_TIM8EN;
	TIM8->DIER|=TIM_DIER_UIE;
	TIM8->PSC=PSC-1;																					//divide APB clock by 256 = 90MHz/256 = 351kHz
	TIM8->ARR = ARR;
	TIM8->CNT=0;
	NVIC->ISER[1]|=(1u<<13);
	TIMER_TIM8_Enable;
}
//----------------------------------------------------------//



//----------------------------------------------------------//
// Function to initiate Timer 4 with variable PSC and ARR values
void TIMER_init_Tim9(int PSC, float ARR)
{
	RCC->APB2ENR|=RCC_APB2ENR_TIM9EN;
	TIM9->DIER|=TIM_DIER_UIE;
	TIM9->PSC=PSC-1;																					//divide APB clock by 256 = 90MHz/256 = 351kHz
	TIM9->ARR = ARR;
	TIM9->CNT=0;
	NVIC->ISER[0]|=(1u<<24);
	TIMER_TIM9_Enable;
}
//----------------------------------------------------------//



//----------------------------------------------------------//
// Function to initiate Timer 4 with variable PSC and ARR values
void TIMER_init_Tim410(int PSC, float ARR)
{
	RCC->APB2ENR|=RCC_APB2ENR_TIM10EN;
	TIM10->DIER|=TIM_DIER_UIE;
	TIM10->PSC=PSC-1;																					//divide APB clock by 256 = 90MHz/256 = 351kHz
	TIM10->ARR = ARR;
	TIM10->CNT=0;
	NVIC->ISER[0]|=(1u<<25);
	TIMER_TIM10_Enable;
}
//----------------------------------------------------------//



//----------------------------------------------------------//
// Function to initiate Timer 4 with variable PSC and ARR values
void TIMER_init_Tim11(int PSC, float ARR)
{
	RCC->APB2ENR|=RCC_APB2ENR_TIM11EN;
	TIM11->DIER|=TIM_DIER_UIE;
	TIM11->PSC=PSC-1;																					//divide APB clock by 256 = 90MHz/256 = 351kHz
	TIM11->ARR = ARR;
	TIM11->CNT=0;
	NVIC->ISER[0]|=(1u<<26);
	TIMER_TIM11_Enable;
}
//----------------------------------------------------------//

//TIMERx INTERRUPT SERVICE ROUTINE
/*
void TIMx_IRQHandler(void)			
{
	TIMx->SR&=~TIM_SR_UIF;			//clear interrupt flag in status register
	//Call a function in main as an inturrupt function
}
*/

#ifndef _LCD_H_
#define _LCD_H_

#define LCD_PORT	GPIOD
#define LCD_RS_pin	11
#define LCD_RW_pin	12
#define LCD_E_pin		13
#define LCD_D0_pin	0
#define LCD_D1_pin	1
#define LCD_D2_pin	2
#define LCD_D3_pin	3
#define LCD_D4_pin	4
#define LCD_D5_pin	5
#define LCD_D6_pin	6
#define LCD_D7_pin	7



#define LCD_LINE1		0x80
#define LCD_LINE2		0xc0

#define LCD_CLEARDISPLAY	0x01

#define set_LCD_RS()	LCD_PORT->BSRR=(1u<<LCD_RS_pin)
#define clr_LCD_RS()	LCD_PORT->BSRR=(1u<<(LCD_RS_pin+16))
#define set_LCD_RW()	LCD_PORT->BSRR=(1u<<LCD_RW_pin)
#define clr_LCD_RW()	LCD_PORT->BSRR=(1u<<(LCD_RW_pin+16))
#define set_LCD_E()		LCD_PORT->BSRR=(1u<<LCD_E_pin)
#define clr_LCD_E()		LCD_PORT->BSRR=(1u<<(LCD_E_pin+16))

#define LCD_CLR()		cmdLCD(0x01)

#define set_LCD_bus_input()		LCD_PORT->MODER&=~(0xffff<<(2*LCD_D0_pin))
#define set_LCD_bus_output()	LCD_PORT->MODER|=(0x5555<<(2*LCD_D0_pin))

#define LCD_CustChar_Add_1	1
#define LCD_CustChar_Add_2	2
#define LCD_CustChar_Add_3	3
#define LCD_CustChar_Add_4	4
#define LCD_CustChar_Add_5	5

#define LCD_MODE  0	//0 = 8bit, 1 = 4bit, default = 8bit

#include <stm32f4xx.h>
#include <stdio.h>

void LCD_delayus(unsigned int us);
void LCD_WaitBusy(void);
void LCD_set_data(unsigned char d);
void LCD_strobe(void);
void LCD_cmd(unsigned char cmd);
void LCD_put(unsigned char put);
void LCD_init(void);
int LCD_getStrLen(unsigned char put[]);
void LCD_Clr(void);

void LCD_putString(unsigned char put[], int Line, int FromRight);
void LCD_putInt(int Val, int Line, int FromRight);

void LCD_Analog_Rep(unsigned short Voltage);

void customchar(int POS, int First, int Second, int Third, int Forth, int Fifth, int Sixth, int Seventh, int Eighth );

void LCD_Load_CustomChar(void);


void LCD_INT_SPRINTF(int val, int line, int fromRight);



#endif

#ifndef _SWITCHES_H_
#define _SWITCHES_H_

#include <stm32f4xx.h>		//INCLUDE THE HEADER FILE FOR THIS MCU FAMILY
	
														//this file contains the definitions for register addresses and values etc...

#define Button_Port GPIOC	
#define Button_Pin 13	

void TIMER_init_ButtonInterrupt(void);


#endif

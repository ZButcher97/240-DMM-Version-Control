#ifndef _PWM_H_
#define _PWM_H_

#include <stm32f4xx.h>

#define PWM_MODE1 0x6
#define PWM_MODE2 0x7

#define LED_PORT GPIOD
#define LED_PIN 15


void PWM_init(void);

#endif 

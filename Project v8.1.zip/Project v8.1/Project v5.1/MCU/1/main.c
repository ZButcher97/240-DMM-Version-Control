#include "main.h"

unsigned char RX_string[64];

//----------------------------------------------------------//
// Main Function
int main(void)
{
	Initalise();
 	while(1)
	{
		__WFI();																								//puts MCU to sleep
		IWDGT_Refresh();																				//This is the watchdog refresh timer
	}
}
//----------------------------------------------------------//






//----------------------------------------------------------//
// Initalise Function
void Initalise(void)
{
	SystemCoreClockUpdate();
	
	LED_init();
	LCD_init();
	ADC_init();
	DAC_init();
	USART_init();
	TIMER_init_ButtonInterrupt();
	IWDGT_init();
	SPI_init();
	//PWM_init();	//causing usart lock-up
	
	TIMER_init_Tim2(1, 1406);																	//This is the value for 1 wave @ 500Hz												
	TIMER_init_Tim3(1, 1875); 
	//(90000000*(1/48000)) = 1875															//48K samples per second, PSC = 1, ARR = 1875
	TIMER_init_Tim4(8, 11250);																//1mS counter for Button pressed time
	//(90,000,000/8)*(1*10^-3) = 11250
	TIMER_init_Tim5(256, 35156);															//100mS timer for HOLD timeout
	
	TIMER_init_Tim7(256, (351/2));														//timer for Frequency counter @ 1mS
	
	
	
}
//----------------------------------------------------------//





//----------------------------------------------------------// INTERRUPT SERVICE ROUTINES
// TIMER 2
void TIM2_IRQHandler(void)			
{
	
	TIM2->SR&=~TIM_SR_UIF;																		//clear interrupt flag in status register
	static int Array_Pos;
	Array_Pos +=1;
	
	if(Array_Pos > 126 ){Array_Pos=0;}
	
	if(MODE == 1) 																						//Sine wave MODE
	{
		DAC_Output(SineWave[Array_Pos]);
	} else if(MODE == 2) 																			//Sawtooth wave MODE
	{
		DAC_Output(SawtoothWave[Array_Pos]);
	} else if(MODE == 3) 																			//Triangle wave MODE
	{
		DAC_Output(TriangleWave[Array_Pos]);
	} else if(MODE == 4) 																			//Square wave MODE
	{
		DAC_Output(SquareWave[Array_Pos]);
	}	else 																										//DC voltage MODE
	{
		DAC_Output(((3.3f-DC_Vol)*4095)/3.3f);
	}
	
}
//----------------------------------------------------------//





//----------------------------------------------------------//
//TIMER 3
void TIM3_IRQHandler(void)			
{
	TIM3->SR&=~TIM_SR_UIF;																		//clear interrupt flag in status register
	static float Average_Buffer[64];													//Real time buffer of 64 samples converted to voltage
	static unsigned short Average_Buffer_Raw[64];							//Real time buffer of 64 samples raw values
	static int Buffer_Pos = 0;																//tracking buffer position
	static int Freq_State = 0;																//flag to determine state of frequency capture
	static int Update_Counter = 0;														//Counter for updating displays
		
	LED_Updates();																						//Update LED states
	
	Average_Buffer_Raw[Buffer_Pos] = ADC_Read();							//Buffer for raw ADC values
	Average_Buffer[Buffer_Pos] = ADC_ConvertVoltage(Average_Buffer_Raw[Buffer_Pos]);		//Buffer for converted ADC values
	
	
	if(!HOLD)
	{
		SPI_transfer(Average_Buffer_Raw[Buffer_Pos]);							//send raw values over spi
	}


	if((Average_Buffer[Buffer_Pos] > (3.3/2)) && (Freq_State == 0))		//if current voltage if greater than center voltage(center line) and state = 0
	{
		// To Do: Start Timer
		TIMER_TIM7_Enable;																							//enable frequency counter
		Freq_State = 1;																									
	} else if((Average_Buffer[Buffer_Pos] < (3.3/2)) && (Freq_State == 1))		//if current voltage if less than center voltage(center line) and state = 1
	{
		Freq_State = 2;
	} else if((Average_Buffer[Buffer_Pos] > (3.3/2)) && (Freq_State == 2))		//if current voltage if greater than center voltage(center line) and state = 2
	{
		Freq_State = 0;																													//reset state to 0
		TIMER_TIM7_Disable;																											//stop timer
		if(Freq_Count == 0)																											//Prevent div(0) -- MCU Lockup
		{
			Freq_Count = 1;														
		}
		Frequency = 1/(Freq_Count*(10^(-3)));																		//Freq = 1/time period
		Freq_Count = 0.0f;																											//reset frequency counter
		// To Do: Reset timer flag
	}
	
	
	
	if(Buffer_Pos >= ADC_Samp_Buff_Val)																				//if current buffer position is greater than or equal to max sample buffer size (default = 64)
	{
		MAX_V = Average_Buffer[0];																							//Max = 1st val of buffer
		for(int i = 1; i<ADC_Samp_Buff_Val; i++)																//loop to itterate through buffer
		{
			if(Average_Buffer[i] > MAX_V){MAX_V = Average_Buffer[i];}							//if current buffer value > Max then Max is updated to this value else do nothing
		}
		
		MIN_V = Average_Buffer[0];																							//Min = 1st val of buffer
		for(int i = 1; i<ADC_Samp_Buff_Val; i++)																//loop to itterate through buffer
		{
			if(Average_Buffer[i] < MIN_V){MIN_V = Average_Buffer[i];}							//if current buffer value < Min then Min is updated to this value else do nothing
		}
		
		Buffer_Pos = 0;																													//Reset buffer position variable
		RMS = MAX_V/sqrt(2);																										//calculate RMS (RMS = V_Peak/Root(2))
		
		
		if(Update_Counter > 480)																								//is display update counter has reached its value(480 -> sample @ 48K, 48K/480 = 100Hz refresh rate
		{
			if(!HOLD)																															//if not in hold state
			{
				USART_putVolt(Average_Buffer[Buffer_Pos]);													//Pass current value of buffer to send to usart voltage position
				LCD_putInt(Average_Buffer[Buffer_Pos], 1, 0);												//Pass current value of buffer to send to lcd top line
				USART_putRMS(RMS);																									//Pass current RMS of buffer to send to usart RMS position
				USART_putMAX(MAX_V);																								//Pass current Max of buffer to send to usart Max position
				USART_putMIN(MIN_V);																								//Pass current Min of buffer to send to usart Min position
				USART_putFREQ(Frequency);																						//Pass current frequency of buffer to send to usart frequency position
				//SPI_transfer(0x0220);																							//used to test SPI LED control on FPGA
				USART_Analog_Rep((Average_Buffer[Buffer_Pos]*4095)/3.3f);					 	//sends current value of buffer as raw data to display analog on usart 
				LCD_Analog_Rep((Average_Buffer[Buffer_Pos]*4095)/3.3f);							//sends current value of buffer as raw data to display analog on LCD
				Update_Counter = 0;																									//Reset update counter
			}
		}
	} else {
		Buffer_Pos++;																														//if buffer position !> buffer max then increment Buffer_pos and update counter
		Update_Counter++;
	}
}
//----------------------------------------------------------//







//----------------------------------------------------------//
//TIMER 4
void TIM4_IRQHandler(void)
{
	TIM4->SR&=~TIM_SR_UIF;																		//clear interrupt flag in status register
	BUTTON_Time += 1;																					//variable to track length of time button has been pressed in mS
}
//----------------------------------------------------------//







//----------------------------------------------------------//
//TIMER 5
void TIM5_IRQHandler(void)																	//function called when MCU is put into HOLD state
{
	TIM5->SR&=~TIM_SR_UIF;																		//clear interrupt flag in status register
	static int HOLD_State = 0;																//variable to track Hold state
	HOLD_State += 1;																					//increment HOLD variable @ 															
	if(HOLD_State > (HOLD_TIMEOUT+1))
	{
		HOLD = 0;
		HOLD_State = 0;
		TIMER_TIM5_Disable;
		USART_ClearLine(9, 1);
		LCD_Clr();
		MAIN_Update_MODE();
	}
}
//----------------------------------------------------------//




//----------------------------------------------------------//
//TIMER 7
void TIM7_IRQHandler(void)
{
	TIM7->SR&=~TIM_SR_UIF;																		//clear interrupt flag in status register
	Freq_Count++;																							//increment frequency counter variable every 1mS
}
//----------------------------------------------------------//





//----------------------------------------------------------//
//Button(Port C Pin 13)
void EXTI15_10_IRQHandler(void)															//Button interrupt handler
{
		
	static int STATE = 0;
	EXTI->PR |= (1 << 13);         														//clear interrupt flag in status register
	if(STATE == 0)																						// Rising edge
	{
		//DEBOUNCE
		MAIN_Delay_us(25000);
		//DEBOUNCE END
		EXTI->RTSR &=~ (1 << 13);																//turn off interrupt for rising edge
		EXTI->FTSR |= (1 << 13);																//turn on interrupt for falling edge
		STATE = 1;																							//state = 1 => rising edge detected, wait for falling edge
		TIMER_TIM4_Enable;																			//start button count timer
	} else {																									
		MAIN_Delay_us(25000);																		//DEBOUNCE
		EXTI->RTSR |= (1 << 13);																//turn on interrupt for rising edge 																
		EXTI->FTSR &=~ (1 << 13);																//turn off interrupt for falling edge
		STATE = 0;																							//state = 0 => falling edge detected, wait for rising edge
		TIMER_TIM4_Disable;																			//stop button count timer
		MAIN_Print_Button_Time();																//function to determine actions depending on button time counted
	}
}
//----------------------------------------------------------//






//----------------------------------------------------------//
void MAIN_Delay_us(unsigned int us)												
{
	unsigned char i;
	while(us--)
	{
		for(i=0; i<SystemCoreClock/4000000; i++);
	}
}
//----------------------------------------------------------//







//----------------------------------------------------------//
void LED_Updates(void)																			//function to update LEDs depending on curret MODE
{
	static int Scaler_index = 0;															//scarler variable for RED led
	Scaler_index = Scaler_index + 1;													//increment scaler 
	if(!HOLD)																									//do if HOLD mode is not current
	{
		if((Scaler_index % 1000) == 0)													//if scaler is divisable by 1000 then toggle red led
		{
			LED_Tog_Red();
		}	
	} else 
	{
		LED_Rst_Red();																					//if HOLD is active, turn off red led
	}
	
	if(MODE == 0)																							//if current mode = 0 (DC) set green led
	{
		LED_Set_Green();
	} else if((MODE == 1) && ((Scaler_index%500) == 0))				//if current mode = 1 (Sine) and scaler is divisable by 500(this sets how ofter the led will toggle) toggle green led
	{
		LED_Tog_Green();
	} else if((MODE == 2) && ((Scaler_index%1000) == 0))			//if current mode = 2 (Sawtooth) and scaler is divisable by 1000 toggle green led
	{
		LED_Tog_Green();
	}	else if((MODE == 3) && ((Scaler_index%2000) == 0))			//if current mode = 3 (Square) and scaler is divisable by 2000 toggle green led
	{
		LED_Tog_Green();
	}	else if((MODE == 4) && ((Scaler_index%4000) == 0))			//if current mode = 4 (Triangle) and scaler is divisable by 4000 toggle green led
	{
		LED_Tog_Green();
	}
	
	if(Scaler_index%4001 == 0)																//if scaler is at or above max val reset scaler variable
	{
		Scaler_index = 0;
	}
}
//----------------------------------------------------------//








//----------------------------------------------------------//
void MAIN_Print_Button_Time(void)														//function to determine action depending on Button pressed time, if longer than a second, HOLD mode, else move to next Wave type mode
{

	if(BUTTON_Time >= 100)																		//if held for longer than a second
	{
		USART_ClearLine(9, 1);																	//print HOLD on USART
		USART_putStr((unsigned char*)"\033[1;31;47m");
		USART_putStr((unsigned char*)"HOLD");
		USART_putStr((unsigned char*)"\033[0m");
		LCD_putString((unsigned char*)"HOLD", 1, 1);
		HOLD = 1;																								//Enable hold mode
		TIMER_TIM5_Enable;																			//start HOLD timer
	} else if(BUTTON_Time <= 99)															//if time is less than 1 second
	{
		MODE += 1;																						//mode to next mode
		MAIN_Update_MODE();																		//update mode
	}
	BUTTON_Time = 0;																					//reset button timer
}
//----------------------------------------------------------//








//----------------------------------------------------------//
void MAIN_Update_MODE(void)																	//function to update usart depending on mode
{
	if(MODE != MODE_Prev)																			//checks mode has changed 
	{
		if(MODE >= 5){MODE = 0;}																//no mode beyond 4, if 5 or more, wrap around to 0
		if(MODE == 0) {																					//DC mode
			USART_ClearLine(6, 8);
			USART_putStr((unsigned char*)"DC\n\r");								//print DC mode
			if(USART_Help_Flag)																		//if Help has previouslly been printed
					{
						USART_Help_Flag = 0;
						USART_ClearHelpList();													//clear help list on USART
					}
					USART_ClearLine(7, 9);
					USART_SetCursor(7, 9);
					USART_putStr((unsigned char*)"Mode changed to DC voltage");	//update console action display output
		} else if(MODE == 1)
		{
			USART_ClearLine(6, 8);
			USART_putStr((unsigned char*)"Sine\n\r");
			if(USART_Help_Flag)
					{
						USART_Help_Flag = 0;
						USART_ClearHelpList();
					}
			USART_ClearLine(7, 9);
			USART_SetCursor(7, 9);
			USART_putStr((unsigned char*)"Mode changed to Sine wave");
			//USART_Mode_Update("Sine");
		} else if(MODE == 2)
		{
			USART_ClearLine(6, 8);
			USART_putStr((unsigned char*)"Sawtooth\n\r");
			if(USART_Help_Flag)
					{
						USART_Help_Flag = 0;
						USART_ClearHelpList();
					}
					USART_ClearLine(7, 9);
					USART_SetCursor(7, 9);
					USART_putStr((unsigned char*)"Mode changed to Sawtooth wave");
			//USART_Mode_Update("Sawtooth");
		} else if(MODE == 3)
		{
			USART_ClearLine(6, 8);
			USART_putStr((unsigned char*)"Triangle\n\r");		
			if(USART_Help_Flag)
					{
						USART_Help_Flag = 0;
						USART_ClearHelpList();
					}
					USART_ClearLine(7, 9);
					USART_SetCursor(7, 9);
					USART_putStr((unsigned char*)"Mode changed to Triangle wave");
			//USART_Mode_Update("Triangle");			
		} else
		{
			USART_ClearLine(6, 8);
			USART_putStr((unsigned char*)"Square  \n\r");
			if(USART_Help_Flag)
					{
						USART_Help_Flag = 0;
						USART_ClearHelpList();
					}
					USART_ClearLine(7, 9);
					USART_SetCursor(7, 9);
					USART_putStr((unsigned char*)"Mode changed to Square wave");
			//USART_Mode_Update("Square");			
		}
	}
	MODE_Prev = MODE;																					//Sets new mode to previouse mode variable
}
//----------------------------------------------------------//







//----------------------------------------------------------//
void MAIN_Refresh(void)																			//function to reset calculated values to 0 
{
	MAX_V = 0;
	MIN_V = 0;
	RMS = 0;
	Frequency = 0;
}
//----------------------------------------------------------//

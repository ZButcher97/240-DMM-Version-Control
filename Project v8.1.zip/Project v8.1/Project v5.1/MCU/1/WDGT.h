#ifndef _WDGT_H_
#define _WDGT_H_
#include <stm32f4xx.h>

#define IWDGT_StartVal 0xcccc
#define IWDGT_ResetVal 0xaaaa
#define IWDGT_UnlockKey 0x5555
//pg 713

void WWDGT_init(void);
void WWDGT_Refresh(void);
void IWDGT_init(void);
void IWDGT_Refresh(void);

#endif

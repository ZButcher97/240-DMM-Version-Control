#ifndef _TIMERS_H_
#define _TIMERS_H_

#include <stm32f4xx.h>		//INCLUDE THE HEADER FILE FOR THIS MCU FAMILY
	
														//this file contains the definitions for register addresses and values etc...

#define TIMER_TIM1_Enable	TIM1->CR1|=TIM_CR1_CEN
#define TIMER_TIM1_Disable	TIM1->CR1&=~(1<<0)

#define TIMER_TIM2_Enable	TIM2->CR1|=TIM_CR1_CEN
#define TIMER_TIM2_Disable	TIM2->CR1&=~(1<<0)

#define TIMER_TIM3_Enable	TIM3->CR1|=TIM_CR1_CEN
#define TIMER_TIM3_Disable	TIM3->CR1&=~(1<<0)

#define TIMER_TIM4_Enable	TIM4->CR1|=TIM_CR1_CEN
#define TIMER_TIM4_Disable	TIM4->CR1&=~(1<<0)

#define TIMER_TIM5_Enable	TIM5->CR1|=TIM_CR1_CEN
#define TIMER_TIM5_Disable	TIM5->CR1&=~(1<<0)

#define TIMER_TIM6_Enable	TIM6->CR1|=TIM_CR1_CEN
#define TIMER_TIM6_Disable	TIM6->CR1&=~(1<<0)

#define TIMER_TIM7_Enable	TIM7->CR1|=TIM_CR1_CEN
#define TIMER_TIM7_Disable	TIM7->CR1&=~(1<<0)

#define TIMER_TIM8_Enable	TIM8->CR1|=TIM_CR1_CEN
#define TIMER_TIM8_Disable	TIM8->CR1&=~(1<<0)

#define TIMER_TIM9_Enable	TIM9->CR1|=TIM_CR1_CEN
#define TIMER_TIM9_Disable	TIM9->CR1&=~(1<<0)

#define TIMER_TIM10_Enable	TIM10->CR1|=TIM_CR1_CEN
#define TIMER_TIM10_Disable	TIM10->CR1&=~(1<<0)

#define TIMER_TIM11_Enable	TIM11->CR1|=TIM_CR1_CEN
#define TIMER_TIM11_Disable	TIM11->CR1&=~(1<<0)

#define TIMER_TIM12_Enable	TIM12->CR1|=TIM_CR1_CEN
#define TIMER_TIM12_Disable	TIM12->CR1&=~(1<<0)

	
void TIMER_init_Tim1(int PSC, float ARR);
void TIMER_init_Tim2(int PSC, float ARR);
void TIMER_init_Tim3(int PSC, float ARR);
void TIMER_init_Tim4(int PSC, float ARR);
void TIMER_init_Tim5(int PSC, float ARR);
void TIMER_init_Tim7(int PSC, float ARR);


#endif

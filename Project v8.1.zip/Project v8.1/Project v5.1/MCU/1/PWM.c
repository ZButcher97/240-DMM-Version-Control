#include "PWM.h"
#include "timers.h"

/*
	Pulse width modulation mode allows generating a signal with a frequency determined by the
	value of the TIMx_ARR register and a duty cycle determined by the value of the
	TIMx_CCRx register.

					The PWM mode can be selected independently on each channel (one PWM per OCx
					output) by writing 110 (PWM mode 1) or �111 (PWM mode 2) in the OCxM bits in the
					TIMx_CCMRx register. 
	
	
					The user must enable the corresponding preload register by setting
					the OCxPE bit in the TIMx_CCMRx register, and eventually the auto-reload preload register
					by setting the ARPE bit in the TIMx_CR1 register.

	As the preload registers are transferred to the shadow registers only when an update event
	occurs, before starting the counter, the user has to initialize all the registers by setting the
	UG bit in the TIMx_EGR register.#

	OCx polarity is software programmable using the CCxP bit in the TIMx_CCER register. It
	can be programmed as active high or active low. OCx output is enabled by the CCxE bit in
	the TIMx_CCER register. Refer to the TIMx_CCERx register description for more details.

	In PWM mode (1 or 2), TIMx_CNT and TIMx_CCRx are always compared to determine
	whether TIMx_CCRx= TIMx_CNT or TIMx_CNT= TIMx_CCRx (depending on the direction
	of the counter). However, to comply with the ETRF (OCREF can be cleared by an external
	event through the ETR signal until the next PWM period), the OCREF signal is asserted
	only:
		� When the result of the comparison changes, or
		� When the output compare mode (OCxM bits in TIMx_CCMRx register) switches from
			the �frozen� configuration (no comparison, OCxM=�000) to one of the PWM modes
			(OCxM=�110 or �111).

	This forces the PWM by software while the timer is running.
	The timer is able to generate PWM in edge-aligned mode or center-aligned mode
	depending on the CMS bits in the TIMx_CR1 register.
	
	110: PWM mode 1 - In upcounting, channel 1 is active as long as TIMx_CNT<TIMx_CCR1
	else inactive. In downcounting, channel 1 is inactive (OC1REF=�0) as long as
	TIMx_CNT>TIMx_CCR1 else active (OC1REF=1).
	111: PWM mode 2 - In upcounting, channel 1 is inactive as long as TIMx_CNT<TIMx_CCR1
	else active. In downcounting, channel 1 is active as long as TIMx_CNT>TIMx_CCR1 else
	inactive.
	Note: In PWM mode 1 or 2, the OCREF level changes only when the result of the
	comparison changes or when the output compare mode switches from �frozen� mode
	to �PWM� mode.
*/
//----------------------------------------------------------//
void PWM_init(void)
{
	
	/*
	Alternate function mapping pg 275
	*/
			//OTYPER, OSPEEDR, PUPDR. 
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIODEN;											//ENABLE PORT(S), ONLY GPIO B clock enable

	LED_PORT->MODER&=~(																			
								(2u<<(2*LED_PIN))
								);
	LED_PORT->MODER |=(																		
								(1u<<(2*LED_PIN))							//AF mode						
								);
	
	LED_PORT->OTYPER&=~(												//Push pull						
								(1u<<(LED_PIN))											
								);
								
								
	LED_PORT->OSPEEDR&=~(												//low speed								
								(3u<<(2*LED_PIN))											
								);
								
	LED_PORT->PUPDR&=~(													//00b is no pull up/pull down						
								(3u<<(2*LED_PIN))											
								);
	
	LED_PORT->AFR[1] = (3<<4*(LED_PIN-8)); //AF3 in pin 15 of GPIOD
	
	TIMER_init_Tim4(1, 9000);	//ARR = 9000, CLK = 90M, PSC = 0 therefore 90M / 10K = 9000, 10k PWM frequency
	//PWM mode 1 = Set on compare match
	//PMW mode 2 = Clear on compare match 
	//mode is set in the OCxM bit in register TIMx_CCMRx
	//User must also enable preload register by setting OCxPE bit in TIMx_CCMRx
	TIM4->CCMR1 &=~ (3<<1); //puts 0b00 in bit1 and bit0, configures CC1 channel to output
	TIM4->CCMR1 |= (PWM_MODE2 << 6);	//Sets PWM mode in the OC1M bits in the CCMR1 Register
	TIM4->CCMR1 |= TIM_CCMR1_OC1CE;
	TIM4->CCMR1 |= TIM_CCMR1_OC1PE;		//Enables preload register bit in CCMR1 register
	TIM4->CR1 |= TIM_CR1_ARPE;
	TIM4->EGR |= TIM_EGR_UG;
	TIM4->CCR1 |= 4500;
}
//----------------------------------------------------------//





//----------------------------------------------------------//
//void PWM_DutyCycle(int DutyCycle)
//{
//	int pulse_length  = (((9000+1)*DutyCycle)/100) - 1;
//}
//----------------------------------------------------------//

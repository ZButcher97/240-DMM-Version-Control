#include "lcd.h"

//----------------------------------------------------------//
void LCD_delayus(unsigned int us)		//blocking delay for LCD, argument is approximate number of micro-seconds to delay
{
	unsigned char i;
	while(us--)
	{
		for(i=0; i<SystemCoreClock/4000000; i++);
	}
}
//----------------------------------------------------------//




//----------------------------------------------------------//
void LCD_WaitBusy(void)
{
	set_LCD_RW();																							//sets cmd lines to read cmd
	clr_LCD_RS();
	set_LCD_bus_input();																			//sets databus to inputs
	
	
	if(LCD_MODE) //4bit
	{
		int Data1 = 0;																						//msbs
		int Data1Mask = 0xf0;																			//mask for msbs
		int Data2 = 0;																						//lsbs
		int Data2Mask = 0x0f;																			//mask for lsbs
		
		while(Data1!=0)																						//while bit 7 != 0
		{
			LCD_delayus(15);																				//set E, read msbs and mask, clr E, set E, read lsbs and mask and bit shift to correct position
			set_LCD_E();																						//, clr E, OR data together, mask bit 7, then loop around and check busy bit until clear
			LCD_delayus(15);
			
			Data1 = LCD_PORT->IDR;
			Data1&=Data1Mask;
			
			clr_LCD_E();
			
			LCD_delayus(15);
			set_LCD_E();
			LCD_delayus(15);
			
			Data2 = ((LCD_PORT->IDR)>>4)&Data2Mask;
			//Data2>>=4;
			//Data2&=Data2Mask;
			
			clr_LCD_E();
			
			Data1|= Data2;
			Data1&=(1<<7);

		}
	} else//8bit
	{
		int Data = 0;
		while(Data!=0)
		{
			LCD_delayus(15);
			set_LCD_E();																						//set E, read date, clr E, Mask bit 7, check busy bit
			LCD_delayus(15);
			
			Data = LCD_PORT->IDR;

			clr_LCD_E();
			
			Data&=(1<<7);
		}
	}


	set_LCD_bus_output();																			//set data bus to output
	
	//LCD_delayus(300);		//3ms blocking delay
}
//----------------------------------------------------------//




//----------------------------------------------------------//
void LCD_set_data(unsigned char d)
{
//		LCD_PORT->BSRR=(0xff<<(LCD_D0_pin+16));	
//		LCD_PORT->BSRR=(d<<LCD_D0_pin);					
	
		LCD_PORT->BSRR=((1<<(LCD_D0_pin+16))|		//clear data lines
										(1<<(LCD_D1_pin+16))|
										(1<<(LCD_D2_pin+16))|
										(1<<(LCD_D3_pin+16))|
										(1<<(LCD_D4_pin+16))|
										(1<<(LCD_D5_pin+16))|
										(1<<(LCD_D6_pin+16))|
										(1<<(LCD_D7_pin+16))
										);
	//d&1<<x will mask data bit x for each pin, >>x will move this bit into the LSB to be placed on the data line
	//without >>x, if bit 2 = 1, then d&1<<2 = 0x04 not 0x01. with >>2, ((d&(1<<2))>>2) = 0x01 
		LCD_PORT->BSRR=((((d&(1<<LCD_D0_pin))>>LCD_D0_pin)<<(LCD_D0_pin))|		//put data on lines
										(((d&(1<<LCD_D1_pin))>>LCD_D1_pin)<<(LCD_D1_pin))|
										(((d&(1<<LCD_D2_pin))>>LCD_D2_pin)<<(LCD_D2_pin))|
										(((d&(1<<LCD_D3_pin))>>LCD_D3_pin)<<(LCD_D3_pin))|
										(((d&(1<<LCD_D4_pin))>>LCD_D4_pin)<<(LCD_D4_pin))|
										(((d&(1<<LCD_D5_pin))>>LCD_D5_pin)<<(LCD_D5_pin))|
										(((d&(1<<LCD_D6_pin))>>LCD_D6_pin)<<(LCD_D6_pin))|
										(((d&(1<<LCD_D7_pin))>>LCD_D7_pin)<<(LCD_D7_pin))
										);
	
}
//----------------------------------------------------------//






//----------------------------------------------------------//
void LCD_strobe(void)		//10us high pulse on LCD enable line
{
	LCD_delayus(10);
	set_LCD_E();
	LCD_delayus(10);
	clr_LCD_E();
}
//----------------------------------------------------------//






//----------------------------------------------------------//
void LCD_cmd(unsigned char cmd)		//sends a byte to the LCD control register
{

	if(LCD_MODE)
	{
		//4bit mode
		LCD_WaitBusy();				//wait for LCD to be not busy
		clr_LCD_RS();					//control command
		clr_LCD_RW();					//write command
		LCD_set_data(cmd&0xf0);		//set data on bus
		LCD_strobe();					//apply command
		
		LCD_WaitBusy();				//wait for LCD to be not busy
		clr_LCD_RS();					//control command
		clr_LCD_RW();					//write command
		LCD_set_data((cmd&0x0f)<<4);		//set data on bus
		LCD_strobe();					//apply command
	} else 
	{
		//8bit mode
		LCD_WaitBusy();				//wait for LCD to be not busy
		clr_LCD_RS();					//control command
		clr_LCD_RW();					//write command
		LCD_set_data(cmd);		//set data on bus
		LCD_strobe();					//apply command
	}
	
	
}
//----------------------------------------------------------//





//----------------------------------------------------------//
void LCD_put(unsigned char put)	//sends a char to the LCD display
{

	if(LCD_MODE)
	{
			//4bit mode
		LCD_WaitBusy();				//wait for LCD to be not busy
		set_LCD_RS();					//text command
		clr_LCD_RW();					//write command
		LCD_set_data(put&0xf0);		//set data on bus
		LCD_strobe();					//apply command
		
		LCD_WaitBusy();				//wait for LCD to be not busy
		set_LCD_RS();					//text command
		clr_LCD_RW();					//write command
		LCD_set_data((put&0x0f)<<4);		//set data on bus
		LCD_strobe();					//apply command
				
	} else 
	{
			//8bit mode
		LCD_WaitBusy();				//wait for LCD to be not busy
		set_LCD_RS();					//text command
		clr_LCD_RW();					//write command
		LCD_set_data(put);		//set data on bus
		LCD_strobe();					//apply command
	}
}
//----------------------------------------------------------//






//----------------------------------------------------------//
void LCD_init(void)
{
		SystemCoreClockUpdate();
		RCC->AHB1ENR|=RCC_AHB1ENR_GPIODEN;	//enable LCD port clock
	
	
			//CONFIG LCD GPIO PINS
		LCD_PORT->MODER&=~(					//clear pin direction settings
			(3u<<(2*LCD_RS_pin))
			|(3u<<(2*LCD_RW_pin))
			|(3u<<(2*LCD_E_pin))
			|(0xffff<<(2*LCD_D0_pin))
			);
	
	
	LCD_PORT->MODER|=(				//reset pin direction settings to digital outputs
			(1u<<(2*LCD_RS_pin))
			|(1u<<(2*LCD_RW_pin))
			|(1u<<(2*LCD_E_pin))
			|(0x5555<<(2*LCD_D0_pin))
		);
	
		LCD_PORT->OTYPER&=~(																			//Resets LED pins output type to 0b, 0b is push pull		
			(1u<<(LCD_RS_pin))											
			|(1u<<(LCD_RS_pin))
			|(1u<<(LCD_RS_pin))
			|(0xFF<<(LCD_D0_pin))
		);
								
								
	LCD_PORT->OSPEEDR&=~(																			//Resets LED pins output speed to 00b, 00b is low speed						
		(3u<<(2*LCD_RS_pin))											
		|(3u<<(2*LCD_RS_pin))
		|(3u<<(2*LCD_RS_pin))
		|(0xFF<<(LCD_D0_pin))
		);
								
	LCD_PORT->PUPDR&=~(																				//Resets LED pins pull up/pull down type to 00b, 00b is no pull up/pull down
		(3u<<(2*LCD_RS_pin))											
		|(3u<<(2*LCD_RS_pin))
		|(3u<<(2*LCD_RS_pin))
		|(0xFF<<(LCD_D0_pin))
		);

	
			//LCD INIT COMMANDS
	clr_LCD_RS();					//all lines default low
	clr_LCD_RW();
	clr_LCD_E();
	
	if(LCD_MODE)
	{
		LCD_delayus(40000);		//40ms startup delay
		LCD_cmd(0x30);
		
		LCD_delayus(100);
		LCD_cmd(0x20);
		LCD_cmd(0x80);
		
		LCD_delayus(100);
		LCD_cmd(0x20);
		LCD_cmd(0x80);
		
		LCD_delayus(100);
		LCD_cmd(0x00);
		LCD_cmd(0xF0);
		
		LCD_delayus(100);
		LCD_cmd(0x00);
		LCD_cmd(0x10);
		
		LCD_delayus(4000);
		LCD_cmd(0x00);
		LCD_cmd(0x60);
		
	} else 
	{
		LCD_delayus(40000);		//40ms startup delay
		LCD_cmd(0x38);	//Function set: 2 Line, 8-bit, 5x7 dots
		LCD_cmd(0x0F);	//Display on, Cursor blinking command
		LCD_cmd(0x01);	//Clear LCD
		LCD_cmd(0x06);	//Entry mode, auto increment with no shift
	}
}
//----------------------------------------------------------//







//----------------------------------------------------------//
void LCD_Clr(void)
{
	LCD_cmd(LCD_CLEARDISPLAY);
}
//----------------------------------------------------------//







//----------------------------------------------------------//
int LCD_getStrLen(unsigned char put[])
{
	for(int i = 0; i < 32; i++)
		{
			if(put[i] == '\0')
			{
				return i;																			//Find the length of the input string.																							//Once Lenght is found, exit loop
			}
		}
		return 0;
}
//----------------------------------------------------------//






//----------------------------------------------------------//
void LCD_ShiftLeft(int Spaces)
{
	for(int i = 0; i<16-Spaces; i++)
	{
		//When enterint here, characters in TestCharFloat changed to 'X' apart from last character
		LCD_cmd(0x14);
	}
}
//----------------------------------------------------------//








//----------------------------------------------------------//
void LCD_putString(unsigned char put[], int Line, int FromRight)
{
	int StrLen = LCD_getStrLen(put);
	if(Line == 1)
	{
		LCD_cmd(LCD_LINE1);
	} else if(Line == 2) {
		LCD_cmd(LCD_LINE2);
	}
	
	if(FromRight)
	{
		LCD_ShiftLeft(StrLen);
		for(int i = 0; i < StrLen; i++)											//Used to input a char, convert into its Ascii
		{																													// and then position in array, and then outputted with LED
			LCD_put(put[i]);		//Does this as many times as the length of the input string
		}	
	}	else 
	{
		for(int i = 0; i < StrLen; i++)											//Used to input a char, convert into its Ascii
		{																													// and then position in array, and then outputted with LED
			LCD_put(put[i]);		//Does this as many times as the length of the input string
		}	
	}
}
//----------------------------------------------------------//








//----------------------------------------------------------//
void LCD_putInt(int Val, int Line, int FromRight)						//function to convert int into char array, then print to LCD on line and fomr right
{	
	unsigned char* put;
	
	int TenThou = 0;
	int Thou = 0;
	int Hund = 0;
	int Tens = 0;
	
	int Size = 0;
	
	if(Val >= 10000)
	{
		Size += 5;
	} else if(Val >= 1000)
	{
		Size += 4;
	} else if(Val >= 100)
	{
		Size += 3;
	} else if(Val >= 10)
	{
		Size += 2;
	} else if(Val >= 1)
	{
		Size += 1;
	}
	if(Size != 0)
	{
		while(Val>10000)
		{
			TenThou += 1;
			Val -= 10000;
		}
		while(Val>1000)
		{
			Thou += 1;
			Val -= 1000;
		}
		while(Val>100)
		{
			Hund += 1;
			Val -= 100;
		}
		while(Val>10)
		{
			Tens += 1;
			Val -= 10;
		}
		if(Size == 5)
		{
			put[0] = TenThou + '0';
			put[1] = Thou + '0';
			put[2] = Hund + '0';
			put[3] = Tens + '0';
			put[4] = Val + '0';
		}else if(Size == 4)
		{
			put[0] = Thou + '0';
			put[1] = Hund + '0';
			put[2] = Tens + '0';
			put[3] = Val + '0';
		}else if(Size == 3)
		{

			put[0] = Hund + '0';
			put[1] = Tens + '0';
			put[2] = Val + '0';		
		}else if(Size == 2)
		{

			put[0] = Tens + '0';
			put[1] = Val + '0';		
		}else if(Size == 1)
		{
			put[0] = Val + '0';		
		}

	} else 
	{
		put[0] = '0';
	}

	LCD_putString(put, Line, FromRight);
}
//----------------------------------------------------------//









//----------------------------------------------------------//
void LCD_putFloat(int Val,int Line,int FromRight)
{	
	unsigned char* put;
	
	for(int i = 0; i< 5; i++)
	{
		put[i] = 0x30;
	}
	
	int TenThou = 0;
	int Thou = 0;
	int Hund = 0;
	int Tens = 0;
	
	int Size = 0;
	
	if(Val >= 10000)
	{
		Size += 5;
	} else if(Val >= 1000)
	{
		Size += 4;
	} else if(Val >= 100)
	{
		Size += 3;
	} else if(Val >= 10)
	{
		Size += 2;
	} else if(Val >= 1)
	{
		Size += 1;
	}
	if(Size != 0)
	{
		while(Val>10000)
		{
			TenThou += 1;
			Val -= 10000;
		}
		while(Val>1000)
		{
			Thou += 1;
			Val -= 1000;
		}
		while(Val>100)
		{
			Hund += 1;
			Val -= 100;
		}
		while(Val>10)
		{
			Tens += 1;
			Val -= 10;
		}
		if(Size == 5)
		{
			put[0] = Thou + '0';
			put[1] = '.';
			put[2] = Hund + '0';
			put[3] = Tens + '0';
			put[4] = Val + '0';
		}else if(Size == 4)
		{
			put[0] = Thou + '0';
			put[1] = '.';
			put[2] = Hund + '0';
			put[3] = Tens + '0';
			put[4] = Val + '0';
		}else if(Size == 3)
		{
			put[0] = '0';
			put[1] = '.';
			put[2] = Hund + '0';
			put[3] = Tens + '0';
			put[4] = Val + '0';		
		}else if(Size == 2)
		{
			put[0] = '0';
			put[1] = '.';
			put[2] = '0';
			put[3] = Tens + '0';
			put[4] = Val + '0';		
		}else if(Size == 1)
		{
			put[0] = '0';
			put[1] = '.';
			put[2] = '0';
			put[3] = '0';
			put[4] = Val + '0';		
		}

	} else 
	{
		put[0] = '0';
	}
	LCD_putString(put, Line, FromRight);
}
//----------------------------------------------------------//





//----------------------------------------------------------//

void LCD_Analog_Rep(unsigned short Voltage)
{
	//LCD_Clr();
	unsigned char Analog_Display[8];
	if(Voltage < 512)
	{
		Analog_Display[0] = '+';
		Analog_Display[1] = ' ';
		Analog_Display[2] = ' ';
		Analog_Display[3] = ' ';
		Analog_Display[4] = ' ';
		Analog_Display[5] = ' ';
		Analog_Display[6] = ' ';
		Analog_Display[7] = ' ';
	} else if(Voltage >= (512*1) && Voltage < (512*2))
	{
		Analog_Display[0] = '+';
		Analog_Display[1] = '+';
		Analog_Display[2] = ' ';
		Analog_Display[3] = ' ';
		Analog_Display[4] = ' ';
		Analog_Display[5] = ' ';
		Analog_Display[6] = ' ';
		Analog_Display[7] = ' ';
	} else if(Voltage >= (512*2) && Voltage < (512*3))
	{
		Analog_Display[0] = '+';
		Analog_Display[1] = '+';
		Analog_Display[2] = '+';
		Analog_Display[3] = ' ';
		Analog_Display[4] = ' ';
		Analog_Display[5] = ' ';
		Analog_Display[6] = ' ';
		Analog_Display[7] = ' ';		
	} else if(Voltage >= (512*3) && Voltage < (512*4))
	{
		Analog_Display[0] = '+';
		Analog_Display[1] = '+';
		Analog_Display[2] = '+';
		Analog_Display[3] = '+';
		Analog_Display[4] = ' ';
		Analog_Display[5] = ' ';
		Analog_Display[6] = ' ';
		Analog_Display[7] = ' ';		
	} else if(Voltage >= (512*4) && Voltage < (512*5))
	{
		Analog_Display[0] = '+';
		Analog_Display[1] = '+';
		Analog_Display[2] = '+';
		Analog_Display[3] = '+';
		Analog_Display[4] = '+';
		Analog_Display[5] = ' ';
		Analog_Display[6] = ' ';
		Analog_Display[7] = ' ';		
	} else if(Voltage >= (512*5) && Voltage < (512*6))
	{
		Analog_Display[0] = '+';
		Analog_Display[1] = '+';
		Analog_Display[2] = '+';
		Analog_Display[3] = '+';
		Analog_Display[4] = '+';
		Analog_Display[5] = '+';
		Analog_Display[6] = ' ';
		Analog_Display[7] = ' ';		
	} else if(Voltage >= (512*6) && Voltage < (512*7))
	{
		Analog_Display[0] = '+';
		Analog_Display[1] = '+';
		Analog_Display[2] = '+';
		Analog_Display[3] = '+';
		Analog_Display[4] = '+';
		Analog_Display[5] = '+';
		Analog_Display[6] = '+';
		Analog_Display[7] = ' ';		
	} else 
	{
		Analog_Display[0] = '+';
		Analog_Display[1] = '+';
		Analog_Display[2] = '+';
		Analog_Display[3] = '+';
		Analog_Display[4] = '+';
		Analog_Display[5] = '+';
		Analog_Display[6] = '+';
		Analog_Display[7] = '+';		
	}
	
	
	LCD_cmd(LCD_LINE2);
	for(int i = 0; i<8; i++)
	{
		LCD_put(Analog_Display[i]);
	}
}
//----------------------------------------------------------//






//----------------------------------------------------------//

void LCD_INT_SPRINTF(int val, int line, int fromRight)
{
	char* test;
	sprintf(test, "%d", val);
	LCD_putString((unsigned char*)test, line, fromRight);	
}
//----------------------------------------------------------//







//----------------------------------------------------------//
float LCD_CharArrToFloat(unsigned char* Data)
{
	int int1 = 0;
	int int2 = 0;
	float ReturnFloat = 0;
	int1 = Data[0] - '0';
	int2 = Data[2] - '0';
	ReturnFloat = ((int1*10)+int2)/10;
	if(ReturnFloat > 3.3f)
		
	{
		ReturnFloat = 3.3f;
	} else if(ReturnFloat < 0.0f)
	{
		ReturnFloat = 0;
	}
	return ReturnFloat;
}
//----------------------------------------------------------//












/*
RS R/W Operation
0 	0 	IR write as an internal operation (display clear, etc.)
0 	1 	Read busy flag (DB7) and address counter (DB0 to DB7)
1 	0 	Write data to DDRAM or CGRAM (DR to DDRAM or CGRAM)
1 	1 	Read data from DDRAM or CGRAM (DDRAM or CGRAM to DR)



 2-Line by 16-Character Display
Display position DDRAM address
1  2  3  4  5  6  7  8  9  10 11 12 13 14 15 16

00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F
40 41 42 43 44 45 46 47 48 49 4A 4B 4C 4D 4E 4F
 

Write into DDRAM the character code at the addresses shown as the left column of table 1. To show
the character patterns stored in CGRAM. 
*/
//----------------------------------------------------------//
const unsigned short LCD_Custom_CHAR[8][8] = {  
	//Byte1    Byte2		Byte3		 Byte4		Byte5		 Byte6		Byte7		 Byte8
   {0x1f, 	 0x11,		0x11, 	 0x11, 		0x11, 	 0x11, 		0x11,		 0x1f}, //Custom Char 1
   {0, 			 0 , 			14,			 14,		  14, 		 14,			14,			 0}, //Custom Char 2
   {0, 			 0 , 			0 , 		 0 , 			14, 		 14, 			14, 		 0}, //Custom Char 3
	 {0, 			 0 , 			0 , 		 0 , 			0 , 		 0 , 			14, 		 0}, //Custom Char 4
	 {0, 			 0 , 			0 , 		 0 , 			0 , 		 0 , 			0 , 		 0}, //Custom Char 5
	 //Above characters used
	 //below characters not used
	 {0, 			 0, 			0, 			 0, 			0, 			 0, 			0, 			 0}, //Custom Char 6
	 {0, 			 0, 			0, 			 0, 			0, 			 0, 			0, 			 0}, //Custom Char 7
	 {0, 			 0, 			0, 			 0, 			0, 			 0, 			0, 			 0}  //Custom Char 8
	 };
//----------------------------------------------------------//
	 
	
	 
	 
	 
	 
//----------------------------------------------------------//
void customchar(int POS, int First, int Second, int Third, int Forth, int Fifth, int Sixth, int Seventh, int Eighth )
{
int i;
	// Array for each line of the LCD cell
	char SpecialCharacter[] = {
  First,  
  Second,
  Third,
  Forth,
  Fifth,
  Sixth,
  Seventh, 
  Eighth	};  
	
	LCD_cmd(0x48 +(0x8 * POS)); // set CGRAM ADDRESS 
	i= 0;

	while (i < 8) // 8 lines high in a cell
	{
		LCD_put(SpecialCharacter[i]); //puting each line into their respective register 
		i++;
	}
	LCD_cmd(0x01*POS);
	LCD_put(0x02);
	
}
//----------------------------------------------------------//











//----------------------------------------------------------//
void LCD_Load_CustomChar(void)
{
	char Test[] = {0x1f, 	 0x1f,		0x1f, 	 0x1f, 		0x1f, 	 0x1f, 		0x1f,		 0x1f};
	
	LCD_cmd(0x48+(0x08*1));
	int i = 0;
	while(i<8)
	{
		LCD_put(Test[i]);
		i++;
	}
	LCD_cmd(0x01);
	
	LCD_put(0x02);
	LCD_put(0x02);
	LCD_put(0x02);

	
	
	
//	for(int i = 0; i<5; i++)
//	{
//		CGRAM_ADD = i;
//		/*							0x40 | CGRAM_Add
//		Set CGRAM RS RW DB7 DB6 DB5 DB4 DB3 DB2 DB1 DB0
//			Address 0  0  0   1   AC5 AC4 AC3 AC2 AC1 AC0 	Set CGRAM address in address counter.
//		0x40 ored CGRAM_Add
//		*/
//		LCD_cmd(0x40|CGRAM_ADD);
//		for(int j = 0; j<8; j++)
//		{
//			//i selects the Custom Char, j selects the byte of the cust char
//			LCD_put(LCD_Custom_CHAR[i][j]);
//		}
//	}
	
	
	
	
	
}
//----------------------------------------------------------//


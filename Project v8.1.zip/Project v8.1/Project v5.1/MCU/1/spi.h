#ifndef _SPI_H_
#define _SPI_H_

#define SPI_PORT	GPIOB
#define SCK_pin		3		//on GPIOB
#define MISO_pin	4		//on GPIOB
#define MOSI_pin	5		//on GPIOB

#define CS_PORT		GPIOA
#define CS_pin		4		//on GPIOA

#define clr_CS()	GPIOA->BSRR=(1u<<(CS_pin+16))
#define set_CS()	GPIOA->BSRR=(1u<<CS_pin)

#include <stm32f4xx.h>

unsigned short SPI_transfer(unsigned short send_val);
void SPI_init_ports(void);
void SPI_init(void);
unsigned short SPI_Send_Voltage(unsigned short Voltage);

#endif
